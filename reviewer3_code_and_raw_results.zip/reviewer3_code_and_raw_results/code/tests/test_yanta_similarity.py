import tempfile
import unittest
import numpy as np
import torch

from yanta_similarity.config import refuse_forbidden_path
from yanta_similarity.features import geometry_features, endpoint_junction_counts, hole_count, skeleton_map
from yanta_similarity.model import YantaSimilarityNet
from yanta_similarity.pairing import monotonic_alignment
from yanta_similarity.perturbations import controlled_perturb


class ModelTests(unittest.TestCase):
    def test_geometry_dimension_and_hole(self):
        mask=np.zeros((128,128),bool);mask[20:108,20:108]=1;mask[45:83,45:83]=0
        self.assertEqual(geometry_features(mask).shape,(32,));self.assertEqual(hole_count(mask),1)

    def test_endpoints(self):
        mask=np.zeros((64,64),bool);mask[32,10:54]=1
        endpoints,_=endpoint_junction_counts(skeleton_map(mask));self.assertEqual(endpoints,2)

    def test_targets_monotone(self):
        gray=np.full((128,128),255,np.uint8);mask=np.zeros_like(gray,bool);mask[20:108,50:75]=1;gray[mask]=20
        _,_,low=controlled_perturb(gray,mask,"topology",.25,np.random.default_rng(1))
        _,_,high=controlled_perturb(gray,mask,"topology",1,np.random.default_rng(1))
        self.assertGreater(low[3],high[3])

    def test_model_output_and_nonnegative_weights(self):
        model=YantaSimilarityNet({"name":"tiny_test"});b=2
        batch={"original_visual":torch.randn(b,3,224,224),"candidate_visual":torch.randn(b,3,224,224),
               "original_structure":torch.randn(b,5,256,256),"candidate_structure":torch.randn(b,5,256,256),
               "geometry_difference":torch.randn(b,32)}
        with torch.no_grad():out=model(batch)
        self.assertEqual(tuple(out["scores"].shape),(b,5));self.assertAlmostEqual(float(out["fusion_weights"].sum()),1.,places=5)
        self.assertTrue(bool((out["fusion_weights"]>=0).all()))

    def test_identical_pair_scores_100(self):
        model=YantaSimilarityNet({"name":"tiny_test"}).eval();b=1
        visual=torch.randn(b,3,224,224);structure=torch.randn(b,5,256,256)
        batch={"original_visual":visual,"candidate_visual":visual.clone(),
               "original_structure":structure,"candidate_structure":structure.clone(),
               "geometry_difference":torch.zeros(b,32)}
        with torch.no_grad():out=model(batch)
        self.assertTrue(torch.allclose(out["scores"],torch.ones_like(out["scores"])))
        self.assertAlmostEqual(float(out["total"].item()),1.0,places=6)

    def test_stroke_width_feature_increases(self):
        thin=np.zeros((128,128),bool);thin[20:108,60:64]=1
        thick=np.zeros((128,128),bool);thick[20:108,52:72]=1
                                                              
        self.assertGreater(float(geometry_features(thick)[14]),float(geometry_features(thin)[14]))

    def test_monotonic_alignment(self):
        sim=np.eye(4,dtype=np.float32);pairs=monotonic_alignment(sim)
        self.assertEqual([(i,j) for i,j,_ in pairs],[(0,0),(1,1),(2,2),(3,3)])

    def test_v2_rejected(self):
        cfg={"data":{"forbid_path_tokens":["linben_cut_v2"]}}
        with self.assertRaises(ValueError):refuse_forbidden_path("E:/论文7/linben_cut_v2",cfg)


if __name__=="__main__":unittest.main()
