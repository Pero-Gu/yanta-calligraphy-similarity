from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd


def main():
    p=argparse.ArgumentParser();p.add_argument("--dataset",type=Path,required=True);p.add_argument("--audit",type=Path,required=True);a=p.parse_args()
    meta_path=a.dataset/"metadata"/"glyphs.csv";audit_path=a.audit/"cut_audit_details.csv"
    meta=pd.read_csv(meta_path);audit=pd.read_csv(audit_path).fillna("")
    keep=audit[["glyph_id","empty_mask","crop_edge_sides","mask_pixels"]].copy()
    keep["reject_reason"]=""
    keep.loc[keep.empty_mask.astype(int)>0,"reject_reason"]="empty_mask"
    keep.loc[(keep.crop_edge_sides.astype(str)!="")&(keep.reject_reason==""),"reject_reason"]="foreground_touches_crop_edge"
    keep.loc[(keep.mask_pixels.astype(int)<80)&(keep.reject_reason==""),"reject_reason"]="very_small_foreground"
    keep["cut_quality"]=keep.reject_reason.map(lambda x:"pass" if not x else "reject")
    keep["usable"]=(keep.cut_quality=="pass").astype(int)
    merged=meta.merge(keep[["glyph_id","cut_quality","usable","reject_reason"]],on="glyph_id",how="left")
    merged.to_csv(meta_path,index=False,encoding="utf-8-sig")
    summary=merged.groupby("writer").agg(total=("glyph_id","size"),saved=("saved","sum"),usable=("usable","sum")).reset_index()
    summary["usable_rate"]=summary.usable/summary.saved.clip(lower=1)
    summary.to_csv(a.audit/"v3_quality_gate_summary.csv",index=False,encoding="utf-8-sig")
    print(summary.to_string(index=False))
if __name__=="__main__":main()
