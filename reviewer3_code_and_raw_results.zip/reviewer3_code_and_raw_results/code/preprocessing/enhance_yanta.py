                     






from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import shutil
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Iterable, Optional

import cv2
import numpy as np
import torch
import yaml
from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader
from scipy import ndimage as ndi
from scipy.signal import find_peaks
from skimage.filters import threshold_sauvola
from skimage.measure import label, regionprops
from skimage.morphology import reconstruction, skeletonize


VERSION = "1.0.0"
REPRESENTATIVE_PAGES = {3, 12, 14, 22}


@dataclass
class Params:
    clahe_clip_limit: float = 2.0
    clahe_grid: tuple[int, int] = (8, 8)
    background_kernel: int = 101
    guided_radius: int = 7
    guided_eps: float = 64.0
    sauvola_window: int = 31
    sauvola_k_strong: float = 0.08
    sauvola_k_weak: float = 0.22
    edge_threshold: float = 0.22
    grid_cols: int = 5
    grid_rows: int = 8
    glyph_margin_fraction: float = -0.05
    standard_size: int = 256
    max_stroke_width_change: float = 0.05
    max_component_growth: float = 0.20
    min_edge_overlap: float = 0.60
    max_background_variance_growth: float = 0.20


@dataclass
class Panel:
    page: int
    panel: int
    x: int
    y: int
    width: int
    height: int


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_pages(spec: str, page_count: int) -> list[int]:
    pages: set[int] = set()
    for item in spec.split(","):
        item = item.strip()
        if not item:
            continue
        if "-" in item:
            start, end = (int(value) for value in item.split("-", 1))
            pages.update(range(start, end + 1))
        else:
            pages.add(int(item))
    result = sorted(page for page in pages if 1 <= page <= page_count)
    if not result:
        raise ValueError("No valid pages were selected")
    return result


def ensure_output_tree(root: Path) -> None:
    paths = [
        "enhanced_pages/original",
        "enhanced_pages/background_corrected",
        "enhanced_pages/contrast_enhanced",
        "enhanced_pages/comparison",
        "enhanced_pages/panels",
        "enhanced_glyphs/raw_color",
        "enhanced_glyphs/gray_enhanced",
        "enhanced_glyphs/mask",
        "enhanced_glyphs/edge",
        "enhanced_glyphs/skeleton",
        "enhanced_glyphs/uncertainty",
        "metadata",
        "models",
    ]
    for relative in paths:
        (root / relative).mkdir(parents=True, exist_ok=True)


def extract_embedded_images(pdf: Path, pages: Iterable[int], out_dir: Path) -> dict[int, Path]:
    reader = PdfReader(str(pdf))
    extracted: dict[int, Path] = {}
    for page_number in pages:
        images = list(reader.pages[page_number - 1].images)
        if not images:
            raise RuntimeError(f"PDF page {page_number} has no embedded raster image")
        image = max(images, key=lambda item: len(item.data))
        suffix = Path(image.name).suffix.lower()
        if suffix not in {".jpg", ".jpeg", ".png", ".jp2", ".tif", ".tiff"}:
            suffix = ".bin"
        destination = out_dir / f"page_{page_number:03d}{suffix}"
        destination.write_bytes(image.data)
        extracted[page_number] = destination
    return extracted


def read_color(path: Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(raw, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Could not decode {path}")
    return image


def write_image(path: Path, image: np.ndarray, quality: int = 95) -> None:
    extension = path.suffix.lower()
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if extension in {".jpg", ".jpeg"} else []
    ok, encoded = cv2.imencode(extension, image, params)
    if not ok:
        raise RuntimeError(f"Could not encode {path}")
    encoded.tofile(str(path))


def odd_at_most(value: int, limit: int) -> int:
    value = min(value, limit)
    if value % 2 == 0:
        value -= 1
    return max(3, value)


def page_enhance(color: np.ndarray, params: Params) -> tuple[np.ndarray, np.ndarray, dict]:
    gray = cv2.cvtColor(color, cv2.COLOR_BGR2GRAY)
    short = min(gray.shape)
    kernel_size = odd_at_most(params.background_kernel, max(3, short // 8))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    background = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)
    scale = float(np.median(background))
    corrected = np.clip(gray.astype(np.float32) * scale / np.maximum(background, 1), 0, 255).astype(np.uint8)
    try:
        denoised = cv2.ximgproc.guidedFilter(
            guide=corrected, src=corrected, radius=params.guided_radius, eps=params.guided_eps
        )
        guided_backend = "opencv_ximgproc"
    except (AttributeError, cv2.error):
        denoised = cv2.bilateralFilter(corrected, 7, 30, 30)
        guided_backend = "bilateral_fallback"
    clahe = cv2.createCLAHE(clipLimit=params.clahe_clip_limit, tileGridSize=params.clahe_grid)
    enhanced = clahe.apply(denoised)
    dark = gray < np.percentile(gray, 35)
    stable_bg = dark & (cv2.morphologyEx(dark.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) > 0)
    base_var = float(np.var(corrected[stable_bg])) if np.any(stable_bg) else 0.0
    new_var = float(np.var(enhanced[stable_bg])) if np.any(stable_bg) else 0.0
    variance_growth = (new_var - base_var) / max(base_var, 1.0)
    if variance_growth > params.max_background_variance_growth:
        enhanced[stable_bg] = corrected[stable_bg]
    return corrected, enhanced, {
        "background_kernel": kernel_size,
        "guided_backend": guided_backend,
        "background_variance_before": base_var,
        "background_variance_after": new_var,
        "background_variance_growth": variance_growth,
        "background_region_reverted": bool(variance_growth > params.max_background_variance_growth),
    }


def detect_panels(gray: np.ndarray, page_number: int) -> list[Panel]:
    height, width = gray.shape
    threshold = min(125, int(np.percentile(gray, 42)))
    mask = (gray < threshold).astype(np.uint8) * 255
                                                                               
                                                                             
                                  
    border_x = max(8, int(width * 0.035))
    border_y = max(8, int(height * 0.035))
    mask[:border_y, :] = 0
    mask[-border_y:, :] = 0
    mask[:, :border_x] = 0
    mask[:, -border_x:] = 0
    kx = odd_at_most(max(31, width // 60), width // 3)
    ky = odd_at_most(max(31, height // 60), height // 3)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((ky, kx), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates: list[tuple[int, int, int, int]] = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        area_fraction = (w * h) / (width * height)
        touches_trimmed_border = x <= border_x or y <= border_y or x + w >= width - border_x or y + h >= height - border_y
        if (
            area_fraction > 0.10
            and h > height * 0.45
            and width * 0.18 < w < width * 0.55
            and not touches_trimmed_border
        ):
            pad = max(2, int(min(w, h) * 0.004))
            candidates.append((max(0, x - pad), max(0, y - pad), min(width - x + pad, w + 2 * pad), min(height - y + pad, h + 2 * pad)))
    candidates = sorted(candidates, key=lambda box: box[2] * box[3], reverse=True)[:2]
    if not candidates:
                                                                                                    
        candidates = [(int(width * .06), int(height * .10), int(width * .88), int(height * .80))]
    elif len(candidates) == 1:
                                                                              
                                                                             
                                                                                
        x, y, w, h = candidates[0]
        mirror_x = width - (x + w)
        mx0 = max(0, mirror_x)
        mx1 = min(width, mirror_x + w)
        my0 = max(0, y)
        my1 = min(height, y + h)
        mirrored_gray = gray[my0:my1, mx0:mx1]
        reference_gray = gray[y : y + h, x : x + w]
        if mirrored_gray.size and float(np.median(mirrored_gray)) < min(155.0, float(np.median(reference_gray)) + 35.0):
            candidates.append((mx0, my0, mx1 - mx0, my1 - my0))
    candidates.sort(key=lambda box: box[0])
    return [Panel(page_number, index + 1, *box) for index, box in enumerate(candidates)]


class EdgeBackend:
    def __init__(self, model_path: Optional[Path], weights_path: Optional[Path], device: str):
        self.name = "scharr_canny_fallback"
        self.model = None
        self.device = torch.device(device)
        self.weights_path = weights_path
        self.weights_sha256 = None
        self.load_error = None
        if not model_path or not weights_path:
            self.load_error = "PiDiNet model path or weights path not supplied"
            return
        try:
            sys.path.insert(0, str(model_path.parent.parent))
            from models.pidinet import pidinet                

            official_args = SimpleNamespace(config="carv4", dil=True, sa=True)
            model = pidinet(official_args)
            checkpoint = torch.load(str(weights_path), map_location="cpu", weights_only=False)
            state = checkpoint.get("state_dict", checkpoint)
            state = {key.removeprefix("module."): value for key, value in state.items()}
            model.load_state_dict(state, strict=True)
            self.model = model.eval().to(self.device)
            self.name = "pidinet_official_pretrained"
            self.weights_sha256 = sha256_file(weights_path)
        except Exception as exc:                                           
            self.load_error = f"{type(exc).__name__}: {exc}"
            self.model = None

    @torch.inference_mode()
    def probability(self, gray: np.ndarray, classical: np.ndarray) -> np.ndarray:
        if self.model is None:
            return classical.astype(np.float32) / 255.0
        rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        tensor = torch.from_numpy(rgb.transpose(2, 0, 1)).float().unsqueeze(0).to(self.device)
        tensor = tensor / 255.0
        outputs = self.model(tensor)
        edge = outputs[-1] if isinstance(outputs, (list, tuple)) else outputs
                                                                                   
        edge = edge[0, 0].detach().cpu().numpy()
        return np.clip(edge, 0.0, 1.0)


def classical_edges(gray: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    gx = cv2.Scharr(gray, cv2.CV_32F, 1, 0)
    gy = cv2.Scharr(gray, cv2.CV_32F, 0, 1)
    magnitude = cv2.magnitude(gx, gy)
    scharr = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    median = float(np.median(gray))
    low = int(max(0, 0.66 * median))
    high = int(min(255, max(low + 1, 1.33 * median)))
    canny = cv2.Canny(gray, low, high, L2gradient=True)
    joint = cv2.max((scharr > np.percentile(scharr, 75)).astype(np.uint8) * 255, canny)
    return scharr, canny, joint


def foreground_masks(gray: np.ndarray, params: Params) -> tuple[np.ndarray, np.ndarray]:
                                                                      
    denoised = cv2.medianBlur(gray, 3)
    try:
        denoised = cv2.ximgproc.guidedFilter(denoised, denoised, radius=4, eps=36.0)
    except (AttributeError, cv2.error):
        pass
    window = odd_at_most(params.sauvola_window, min(gray.shape) - 1)
    threshold_strong = threshold_sauvola(denoised, window_size=window, k=params.sauvola_k_strong)
    threshold_weak = threshold_sauvola(denoised, window_size=window, k=params.sauvola_k_weak)
    otsu, _ = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    strong_floor = max(float(otsu) + 0.12 * (255.0 - float(otsu)), float(np.percentile(denoised, 68)))
    weak_floor = max(float(otsu) * 0.86, float(np.percentile(denoised, 52)))
    strong = (denoised > threshold_strong) & (denoised > strong_floor)
    weak = (denoised > threshold_weak) & (denoised > weak_floor)
    weak |= strong
    return strong, weak


def reconstruction_cleanup(mask: np.ndarray, radius: int) -> np.ndarray:
    mask_u8 = mask.astype(np.uint8)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * radius + 1, 2 * radius + 1))
    eroded = cv2.erode(mask_u8, kernel)
    opened = reconstruction(eroded, mask_u8, method="dilation") > 0
                                                                                 
    complement = (~opened).astype(np.uint8)
    marker = cv2.erode(complement, kernel)
    closed_complement = reconstruction(marker, complement, method="dilation") > 0
    return ~closed_complement


def estimate_stroke_width(mask: np.ndarray) -> float:
    if not np.any(mask):
        return 1.0
    bounded = mask.copy()
    bounded[[0, -1], :] = False
    bounded[:, [0, -1]] = False
    if not np.any(bounded):
        return 1.0
    distance = cv2.distanceTransform(bounded.astype(np.uint8), cv2.DIST_L2, 5)
    skeleton = skeletonize(bounded)
    values = 2.0 * distance[skeleton]
    values = values[values > 0]
    return float(np.median(values)) if values.size else 1.0


def stable_component_count(mask: np.ndarray, stroke_width: float) -> int:
    labels = label(mask, connectivity=2)
    minimum = max(2.0, stroke_width * stroke_width * 0.25)
    return sum(region.area >= minimum for region in regionprops(labels))


def fill_only_pinholes(mask: np.ndarray, stroke_width: float) -> np.ndarray:
    holes = ndi.binary_fill_holes(mask) & ~mask
    labels = label(holes, connectivity=1)
    result = mask.copy()
    maximum = max(1.0, stroke_width * stroke_width)
    for region in regionprops(labels):
        if region.area < maximum:
            coords = region.coords
            result[coords[:, 0], coords[:, 1]] = True
    return result


def prune_texture_components(mask: np.ndarray, stroke_width: float, edge_support: Optional[np.ndarray] = None) -> np.ndarray:

    labels = label(mask, connectivity=2)
    regions = regionprops(labels)
    if not regions:
        return mask
    area_floor = max(4.0, stroke_width * stroke_width * 0.40, mask.size * 0.0008)
    largest = max(regions, key=lambda region: region.area)
    stable_labels = {largest.label}
    main = labels == largest.label
    main_distance = ndi.distance_transform_edt(~main)
    if edge_support is not None:
        edge_support = cv2.dilate(edge_support.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
    for region in regions:
        if region.label == largest.label or region.area < area_floor:
            continue
        coords = region.coords
        near_main = np.min(main_distance[coords[:, 0], coords[:, 1]]) <= max(3.0, 3.0 * stroke_width)
        edge_fraction = 0.0
        if edge_support is not None:
            edge_fraction = float(edge_support[coords[:, 0], coords[:, 1]].mean())
        if near_main or edge_fraction >= 0.08:
            stable_labels.add(region.label)
    stable = np.isin(labels, list(stable_labels))
    distance = ndi.distance_transform_edt(~stable)
    protected_distance = max(2.0, 1.75 * stroke_width)
    result = stable.copy()
    for region in regions:
        if region.label in stable_labels:
            continue
        coords = region.coords
        if np.min(distance[coords[:, 0], coords[:, 1]]) <= protected_distance:
            result[coords[:, 0], coords[:, 1]] = True
    return result


def enhance_glyph(gray: np.ndarray, edge_backend: EdgeBackend, params: Params) -> dict:
    strong, weak = foreground_masks(gray, params)
    scharr, canny, classical = classical_edges(gray)
    edge_probability = edge_backend.probability(gray, classical)
    scharr_probability = scharr.astype(np.float32) / 255.0
    supported_edge = (edge_probability >= params.edge_threshold) & (scharr_probability >= 0.15)
    growth_mask = weak | cv2.dilate(supported_edge.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
    marker = strong & growth_mask
    grown = reconstruction(marker.astype(np.uint8), growth_mask.astype(np.uint8), method="dilation") > 0
    base_width = estimate_stroke_width(strong)
    radius = int(np.clip(round(base_width / 8.0), 1, 3))
    baseline = fill_only_pinholes(reconstruction_cleanup(strong, radius), base_width)
    fused = fill_only_pinholes(reconstruction_cleanup(grown, radius), base_width)
    edge_support_for_pruning = edge_probability >= 0.15
    baseline = prune_texture_components(baseline, estimate_stroke_width(baseline), edge_support_for_pruning)
    fused = prune_texture_components(fused, estimate_stroke_width(fused), edge_support_for_pruning)

    baseline_width = estimate_stroke_width(baseline)
    fused_width = estimate_stroke_width(fused)
    width_change = abs(fused_width - baseline_width) / max(baseline_width, 1.0)
    base_components = stable_component_count(baseline, baseline_width)
    fused_components = stable_component_count(fused, fused_width)
    component_growth = (fused_components - base_components) / max(base_components, 1)
    edge_pixels = supported_edge.sum()
    edge_overlap = float((supported_edge & cv2.dilate(strong.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)).sum() / max(edge_pixels, 1))
    outside = ~cv2.dilate(weak.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool)
    background_edges = int((supported_edge & outside).sum())
    stroke_edges = int((supported_edge & ~outside).sum())
    reasons: list[str] = []
    if width_change > params.max_stroke_width_change:
        reasons.append("stroke_width_change")
    if component_growth > params.max_component_growth:
        reasons.append("component_growth")
    if edge_overlap < params.min_edge_overlap:
        reasons.append("low_edge_overlap")
    if background_edges > stroke_edges:
        reasons.append("background_pseudo_edges")
    final = baseline if reasons else fused
    uncertainty = np.mean(
        np.stack([strong.astype(np.float32), weak.astype(np.float32), fused.astype(np.float32)], axis=0), axis=0
    )
    uncertainty = 1.0 - np.abs(uncertainty - 0.5) * 2.0
    return {
        "mask": final,
        "baseline": baseline,
        "fused": fused,
        "edge": edge_probability,
        "skeleton": skeletonize(final),
        "uncertainty": uncertainty,
        "fallback_reasons": reasons,
        "stroke_width_baseline": baseline_width,
        "stroke_width_final": estimate_stroke_width(final),
        "stroke_width_change": width_change,
        "components_baseline": base_components,
        "components_fused": fused_components,
        "component_growth": component_growth,
        "edge_overlap": edge_overlap,
        "background_edges": background_edges,
        "stroke_edges": stroke_edges,
        "kernel_radius": radius,
    }


def fit_canvas(image: np.ndarray, size: int, background: int | tuple[int, int, int]) -> np.ndarray:
    height, width = image.shape[:2]
    scale = min((size - 16) / max(width, 1), (size - 16) / max(height, 1))
    new_size = (max(1, int(round(width * scale))), max(1, int(round(height * scale))))
    is_binary = image.dtype == bool
    if image.ndim == 2 and not is_binary:
        values = np.unique(image)
        is_binary = bool(values.size <= 3 and set(values.tolist()).issubset({0, 1, 255}))
    interpolation = cv2.INTER_NEAREST if is_binary else cv2.INTER_AREA
    resized = cv2.resize(image.astype(np.uint8), new_size, interpolation=interpolation)
    if image.ndim == 3:
        canvas = np.full((size, size, 3), background, dtype=np.uint8)
    else:
        canvas = np.full((size, size), background, dtype=np.uint8)
    x = (size - new_size[0]) // 2
    y = (size - new_size[1]) // 2
    canvas[y : y + new_size[1], x : x + new_size[0]] = resized
    return canvas


def projection_centers(panel_gray: np.ndarray, axis: int, count: int) -> tuple[np.ndarray, str]:

    if axis == 0:
        baseline = np.percentile(panel_gray, 55, axis=0, keepdims=True)
        signal = np.clip(panel_gray.astype(np.float32) - baseline, 0, None).sum(axis=0)
    else:
        baseline = np.percentile(panel_gray, 55, axis=1, keepdims=True)
        signal = np.clip(panel_gray.astype(np.float32) - baseline, 0, None).sum(axis=1)
    length = signal.size
    sigma = max(3.0, length / (count * 20.0))
    smooth = ndi.gaussian_filter1d(signal, sigma=sigma)
    peaks, _ = find_peaks(
        smooth,
        distance=max(3, int(length / (count * 1.55))),
        prominence=max(1.0, float(np.ptp(smooth)) * 0.02),
    )
    if peaks.size >= count:
        strongest = peaks[np.argsort(smooth[peaks])[-count:]]
        return np.sort(strongest.astype(np.float32)), "projection"
    centers = (np.arange(count, dtype=np.float32) + 0.5) * length / count
    return centers, "equal_fallback"


def panel_cells(
    panel: Panel, params: Params, panel_gray: np.ndarray
) -> Iterable[tuple[int, int, tuple[int, int, int, int], str, int, int]]:
    x_centers, x_mode = projection_centers(panel_gray, axis=0, count=params.grid_cols)
    y_centers, y_mode = projection_centers(panel_gray, axis=1, count=params.grid_rows)
    x_spacing = float(np.median(np.diff(x_centers))) if len(x_centers) > 1 else panel.width / params.grid_cols
    y_spacing = float(np.median(np.diff(y_centers))) if len(y_centers) > 1 else panel.height / params.grid_rows
                                                                             
                                                                             
    half_width = 0.5 * x_spacing * (1.0 - 2.0 * params.glyph_margin_fraction)
    half_height = 0.5 * y_spacing * (1.0 - 2.0 * params.glyph_margin_fraction)
    for col, center_x in enumerate(x_centers, start=1):
        for row, center_y in enumerate(y_centers, start=1):
            local_x0 = max(0, int(math.floor(center_x - half_width)))
            local_y0 = max(0, int(math.floor(center_y - half_height)))
            local_x1 = min(panel.width, int(math.ceil(center_x + half_width)))
            local_y1 = min(panel.height, int(math.ceil(center_y + half_height)))
            yield (
                col,
                row,
                (panel.x + local_x0, panel.y + local_y0, panel.x + local_x1, panel.y + local_y1),
                f"x:{x_mode};y:{y_mode}",
                int(round(panel.x + center_x)),
                int(round(panel.y + center_y)),
            )


def make_page_comparison(original: np.ndarray, corrected: np.ndarray, enhanced: np.ndarray, panels: list[Panel]) -> np.ndarray:
    previews = []
    for source in [cv2.cvtColor(original, cv2.COLOR_BGR2GRAY), corrected, enhanced]:
        preview = cv2.cvtColor(source, cv2.COLOR_GRAY2BGR)
        for panel in panels:
            cv2.rectangle(preview, (panel.x, panel.y), (panel.x + panel.width, panel.y + panel.height), (0, 0, 255), 4)
        previews.append(preview)
    target_width = 800
    resized = [cv2.resize(item, (target_width, int(item.shape[0] * target_width / item.shape[1])), interpolation=cv2.INTER_AREA) for item in previews]
    labels = ["Original gray", "Background corrected", "Guided + CLAHE"]
    for image, label_text in zip(resized, labels):
        cv2.rectangle(image, (0, 0), (330, 45), (255, 255, 255), -1)
        cv2.putText(image, label_text, (10, 31), cv2.FONT_HERSHEY_SIMPLEX, .8, (0, 0, 0), 2, cv2.LINE_AA)
    return np.hstack(resized)


def save_glyph_outputs(root: Path, glyph_id: str, raw: np.ndarray, gray: np.ndarray, result: dict, size: int) -> None:
    raw_canvas = fit_canvas(raw, size, (255, 255, 255))
    gray_canvas = fit_canvas(255 - gray, size, 255)                                 
    mask_canvas = fit_canvas((~result["mask"]).astype(np.uint8) * 255, size, 255)
    edge_canvas = fit_canvas(((1.0 - result["edge"]) * 255).astype(np.uint8), size, 255)
    skeleton_canvas = fit_canvas((~result["skeleton"]).astype(np.uint8) * 255, size, 255)
    uncertainty_canvas = fit_canvas((result["uncertainty"] * 255).astype(np.uint8), size, 0)
    write_image(root / "enhanced_glyphs/raw_color" / f"{glyph_id}.png", raw_canvas)
    write_image(root / "enhanced_glyphs/gray_enhanced" / f"{glyph_id}.png", gray_canvas)
    write_image(root / "enhanced_glyphs/mask" / f"{glyph_id}.png", mask_canvas)
    write_image(root / "enhanced_glyphs/edge" / f"{glyph_id}.png", edge_canvas)
    write_image(root / "enhanced_glyphs/skeleton" / f"{glyph_id}.png", skeleton_canvas)
    write_image(root / "enhanced_glyphs/uncertainty" / f"{glyph_id}.png", uncertainty_canvas)


def run(args: argparse.Namespace) -> int:
    started = time.perf_counter()
    input_pdf = Path(args.input).resolve()
    output = Path(args.output).resolve()
    if not input_pdf.exists():
        raise FileNotFoundError(input_pdf)
    ensure_output_tree(output)
    reader = PdfReader(str(input_pdf))
    pages = parse_pages(args.pages, len(reader.pages))
    del reader
    params = Params(grid_cols=args.grid_cols, grid_rows=args.grid_rows)
    extracted = extract_embedded_images(input_pdf, pages, output / "enhanced_pages/original")
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    model_path = Path(args.pidinet_model).resolve() if args.pidinet_model else None
    weights_path = Path(args.pidinet_weights).resolve() if args.pidinet_weights else None
    edge_backend = EdgeBackend(model_path, weights_path, device)

    panel_rows: list[dict] = []
    glyph_rows: list[dict] = []
    page_rows: list[dict] = []
    for page_number in pages:
        page_started = time.perf_counter()
        color = read_color(extracted[page_number])
        gray = cv2.cvtColor(color, cv2.COLOR_BGR2GRAY)
        corrected, enhanced, page_metrics = page_enhance(color, params)
        panels = detect_panels(gray, page_number)
        write_image(output / "enhanced_pages/background_corrected" / f"page_{page_number:03d}.png", corrected)
        write_image(output / "enhanced_pages/contrast_enhanced" / f"page_{page_number:03d}.png", enhanced)
        comparison = make_page_comparison(color, corrected, enhanced, panels)
        write_image(output / "enhanced_pages/comparison" / f"page_{page_number:03d}.jpg", comparison, 92)
        for panel in panels:
            panel_rows.append(asdict(panel))
            panel_crop = color[panel.y : panel.y + panel.height, panel.x : panel.x + panel.width]
            write_image(output / "enhanced_pages/panels" / f"page_{page_number:03d}_panel_{panel.panel:02d}.png", panel_crop)
            panel_gray = enhanced[panel.y : panel.y + panel.height, panel.x : panel.x + panel.width]
            for col, row, (x0, y0, x1, y1), grid_mode, center_x, center_y in panel_cells(panel, params, panel_gray):
                raw_crop = color[y0:y1, x0:x1]
                gray_crop = enhanced[y0:y1, x0:x1]
                result = enhance_glyph(gray_crop, edge_backend, params)
                coverage = float(result["mask"].mean())
                is_blank = coverage < args.min_coverage or coverage > args.max_coverage
                glyph_id = f"p{page_number:03d}_s{panel.panel:02d}_c{col:02d}_r{row:02d}"
                if not is_blank or args.keep_blank:
                    save_glyph_outputs(output, glyph_id, raw_crop, gray_crop, result, params.standard_size)
                glyph_rows.append({
                    "glyph_id": glyph_id,
                    "page": page_number,
                    "panel": panel.panel,
                    "column_left_to_right": col,
                    "column_right_to_left": params.grid_cols - col + 1,
                    "row_top_to_bottom": row,
                    "grid_detection": grid_mode,
                    "grid_center_x": center_x,
                    "grid_center_y": center_y,
                    "pdf_image_x": x0,
                    "pdf_image_y": y0,
                    "width": x1 - x0,
                    "height": y1 - y0,
                    "foreground_coverage": coverage,
                    "is_blank": is_blank,
                    "saved": (not is_blank or args.keep_blank),
                    "method_requested": args.method,
                    "edge_backend": edge_backend.name,
                    "fallback": bool(result["fallback_reasons"]),
                    "fallback_reasons": ";".join(result["fallback_reasons"]),
                    "stroke_width_baseline": result["stroke_width_baseline"],
                    "stroke_width_final": result["stroke_width_final"],
                    "stroke_width_change": result["stroke_width_change"],
                    "components_baseline": result["components_baseline"],
                    "components_fused": result["components_fused"],
                    "component_growth": result["component_growth"],
                    "edge_overlap": result["edge_overlap"],
                    "background_edges": result["background_edges"],
                    "stroke_edges": result["stroke_edges"],
                    "kernel_radius": result["kernel_radius"],
                })
        page_rows.append({
            "page": page_number,
            "source_image": str(extracted[page_number]),
            "source_image_sha256": sha256_file(extracted[page_number]),
            "pixel_width": color.shape[1],
            "pixel_height": color.shape[0],
            "panels_detected": len(panels),
            "representative_page": page_number in REPRESENTATIVE_PAGES,
            "processing_seconds": time.perf_counter() - page_started,
            **page_metrics,
        })
        print(f"page {page_number:03d}: {len(panels)} panels, {time.perf_counter() - page_started:.1f}s", flush=True)

    def write_csv(name: str, rows: list[dict]) -> None:
        if not rows:
            return
        with (output / "metadata" / name).open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    write_csv("pages.csv", page_rows)
    write_csv("panels.csv", panel_rows)
    write_csv("glyphs.csv", glyph_rows)
    saved_count = sum(bool(row["saved"]) for row in glyph_rows)
    fallback_count = sum(bool(row["fallback"]) for row in glyph_rows if row["saved"])
    config = {
        "pipeline": {"name": "Yanta non-generative enhancement", "version": VERSION, "method": args.method},
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input": {"pdf": str(input_pdf), "pdf_sha256": sha256_file(input_pdf), "pages": pages},
        "model": {
            "edge_backend": edge_backend.name,
            "device": device,
            "weights": str(weights_path) if weights_path else None,
            "weights_sha256": edge_backend.weights_sha256,
            "load_error": edge_backend.load_error,
        },
        "parameters": asdict(params),
        "output": {
            "root": str(output),
            "glyph_cells_total": len(glyph_rows),
            "glyphs_saved": saved_count,
            "fallback_count": fallback_count,
            "processing_seconds": time.perf_counter() - started,
        },
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": str(torch.__version__),
            "cuda_available": torch.cuda.is_available(),
            "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "opencv": cv2.__version__,
        },
        "scientific_constraints": {
            "generative_inpainting": False,
            "non_uniform_scaling": False,
            "classification": False,
            "missing_stroke_hallucination": False,
            "coordinate_system": "top-left origin in extracted embedded image pixels",
        },
    }
    with (output / "metadata/config.yaml").open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, allow_unicode=True, sort_keys=False)
    with (output / "metadata/run_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(config["output"] | config["model"], handle, ensure_ascii=False, indent=2)
    print(json.dumps(config["output"] | config["model"], ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Source PDF; never modified")
    parser.add_argument("--pages", default="3-22", help="1-based pages, e.g. 3-22 or 3,12,14,22")
    parser.add_argument("--method", default="pidinet_morph", choices=["pidinet_morph", "sauvola_morph"])
    parser.add_argument("--output", default="yanta_enhanced")
    parser.add_argument("--pidinet-model", help="Official repository models/pidinet.py")
    parser.add_argument("--pidinet-weights", help="Official pretrained .pth checkpoint")
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--grid-cols", type=int, default=5)
    parser.add_argument("--grid-rows", type=int, default=8)
    parser.add_argument("--min-coverage", type=float, default=0.008)
    parser.add_argument("--max-coverage", type=float, default=0.65)
    parser.add_argument("--keep-blank", action="store_true", help="Also export cells detected as blank")
    return parser


if __name__ == "__main__":
    raise SystemExit(run(build_parser().parse_args()))
