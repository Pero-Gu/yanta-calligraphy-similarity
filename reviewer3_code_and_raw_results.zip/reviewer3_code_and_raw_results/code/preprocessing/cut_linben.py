from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


@dataclass(frozen=True)
class Layout:
    cols: int
    rows: int
    panels: int = 1
                                                                 
    inset_left: float = 0.015
    inset_top: float = 0.015
    inset_right: float = 0.015
    inset_bottom: float = 0.015
    crop_pad: float = 0.08


LAYOUTS = {
    "洪厚田": Layout(3, 5, crop_pad=0.10),
    "王澍": Layout(4, 7, panels=2, inset_left=0.080, inset_top=0.080,
                 inset_right=0.080, inset_bottom=0.080, crop_pad=0.08),
    "翁志飞": Layout(4, 6, crop_pad=0.10),
    "赵世骏": Layout(4, 7, inset_left=0.025, inset_top=0.010,
                  inset_right=0.025, inset_bottom=0.010, crop_pad=0.07),
    "郭尚先": Layout(5, 7, crop_pad=0.09),
                                                                              
                                                                             
                                                                                
                                                                                
    "黄自元": Layout(4, 8, inset_left=0.055, inset_top=0.110,
                  inset_right=0.135, inset_bottom=0.030, crop_pad=0.18),
}

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


def natural_key(path: Path) -> tuple:
    stem = path.stem
    return (0, int(stem)) if stem.isdigit() else (1, stem.casefold())


def read_image(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Cannot read image: {path}")
    return image


def write_image(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower() or ".png"
    ok, encoded = cv2.imencode(suffix, image)
    if not ok:
        raise RuntimeError(f"Cannot encode image: {path}")
    encoded.tofile(str(path))


def fit_canvas(image: np.ndarray, size: int, background) -> np.ndarray:
    h, w = image.shape[:2]
    scale = min((size - 16) / max(w, 1), (size - 16) / max(h, 1))
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    binary = image.ndim == 2 and set(np.unique(image).tolist()).issubset({0, 255})
    interpolation = cv2.INTER_NEAREST if binary else cv2.INTER_AREA
    resized = cv2.resize(image, (nw, nh), interpolation=interpolation)
    shape = (size, size, 3) if image.ndim == 3 else (size, size)
    canvas = np.full(shape, background, dtype=np.uint8)
    x, y = (size - nw) // 2, (size - nh) // 2
    canvas[y:y + nh, x:x + nw] = resized
    return canvas


def sheet_bbox(image: np.ndarray, writer: str) -> tuple[int, int, int, int]:

    h, w = image.shape[:2]
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    light = lab[:, :, 0] > 92
                                                                                 
    kx = max(11, w // 28)
    ky = max(11, h // 45)
    mask = cv2.morphologyEx(light.astype(np.uint8) * 255, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_RECT, (kx, ky)))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    candidates = []
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if bw > 0.45 * w and bh > 0.45 * h:
            candidates.append((int(area), (int(x), int(y), int(x + bw), int(y + bh))))
    if not candidates:
        return 0, 0, w, h
    _, box = max(candidates)
    x0, y0, x1, y1 = box
                                                                                
    row_luma = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY).mean(axis=1)
    dark_rows = np.where(row_luma < 45)[0]
    if dark_rows.size and dark_rows[-1] == h - 1 and dark_rows[0] > h * 0.75:
        y1 = min(y1, int(dark_rows[0]))
    return x0, y0, x1, y1


def panel_boxes(image: np.ndarray, writer: str, layout: Layout) -> list[tuple[int, int, int, int]]:
    x0, y0, x1, y1 = sheet_bbox(image, writer)
    if layout.panels == 1:
        return [(x0, y0, x1, y1)]
                                                                            
                                                                                
                                                                                   
    mid = (x0 + x1) // 2
    return [(x0, y0, mid, y1), (mid, y0, x1, y1)]


def inset_box(box: tuple[int, int, int, int], layout: Layout) -> tuple[int, int, int, int]:
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    return (round(x0 + layout.inset_left * w), round(y0 + layout.inset_top * h),
            round(x1 - layout.inset_right * w), round(y1 - layout.inset_bottom * h))


def ink_mask(crop: np.ndarray) -> np.ndarray:

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB)
                                                                                
    radius = max(15, int(round(min(gray.shape) * 0.18))) | 1
    background = cv2.GaussianBlur(gray, (0, 0), radius / 3.0)
    corrected = cv2.divide(gray, np.maximum(background, 1), scale=235)
    block = max(25, (min(gray.shape) // 5) | 1)
    adaptive = cv2.adaptiveThreshold(corrected, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                     cv2.THRESH_BINARY_INV, block, 9)
                                                                                 
    red = ((hsv[:, :, 0] < 18) | (hsv[:, :, 0] > 170)) & (hsv[:, :, 1] > 70)
                                                                            
                                                                              
                                                                         
    dark = lab[:, :, 0] < 195
    mask = ((adaptive > 0) & dark & ~red).astype(np.uint8) * 255
                                                                                  
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(15, int(crop.shape[1] * .72)), 1))
    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(15, int(crop.shape[0] * .72))))
    lines = cv2.morphologyEx(mask, cv2.MORPH_OPEN, h_kernel)
    lines |= cv2.morphologyEx(mask, cv2.MORPH_OPEN, v_kernel)
    mask[lines > 0] = 0
                                                                               
                                                                          
    return mask


def retain_character(mask: np.ndarray, core: tuple[int, int, int, int]) -> np.ndarray:

    n, labels, stats, centers = cv2.connectedComponentsWithStats(mask, 8)
    x0, y0, x1, y1 = core
    result = np.zeros_like(mask)
    min_area = max(3, round(mask.size * 0.00018))
                                                                              
                                                                           
                                                                              
                   
    central_x0, central_x1 = mask.shape[1] * .18, mask.shape[1] * .82
    central_y0, central_y1 = mask.shape[0] * .16, mask.shape[0] * .84
    candidates = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        cx, cy = centers[i]
        in_core = x0 <= cx < x1 and y0 <= cy < y1
        touches_edge = x <= 2 or y <= 2 or x + w >= mask.shape[1] - 2 or y + h >= mask.shape[0] - 2
        reaches_centre = (x < central_x1 and x + w > central_x0 and
                          y < central_y1 and y + h > central_y0)
                                                                              
        if (in_core and area >= min_area and not (w <= 2 and h <= 2)
                and (not touches_edge or reaches_centre)):
            candidates.append(i)
    if not candidates:
        return result
    largest = max(int(stats[i, cv2.CC_STAT_AREA]) for i in candidates)
    major = [i for i in candidates if stats[i, cv2.CC_STAT_AREA] >= max(40, largest * .02)]
    if not major:
        major = [max(candidates, key=lambda i: stats[i, cv2.CC_STAT_AREA])]
                                                                          
                                                                              
                                                                              
    parent = {i: i for i in major}
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    def union(a, b):
        a, b = root(a), root(b)
        if a != b: parent[b] = a
    link_x, link_y = mask.shape[1] * .075, mask.shape[0] * .075
    for pos, i in enumerate(major):
        xi, yi, wi, hi, _ = stats[i]
        for j in major[pos + 1:]:
            xj, yj, wj, hj, _ = stats[j]
            gap_x = max(0, max(xi, xj) - min(xi + wi, xj + wj))
            gap_y = max(0, max(yi, yj) - min(yi + hi, yj + hj))
            if gap_x <= link_x and gap_y <= link_y: union(i, j)
    groups = {}
    for i in major: groups.setdefault(root(i), []).append(i)
    core_cx, core_cy = (x0 + x1) / 2, (y0 + y1) / 2
    def group_score(group):
        area = sum(float(stats[i, cv2.CC_STAT_AREA]) for i in group)
        cx = sum(float(centers[i][0]) * stats[i, cv2.CC_STAT_AREA] for i in group) / area
        cy = sum(float(centers[i][1]) * stats[i, cv2.CC_STAT_AREA] for i in group) / area
        distance = ((cx-core_cx)/max(1,x1-x0))**2 + ((cy-core_cy)/max(1,y1-y0))**2
        return area / (1 + 1.5 * distance)
    selected = max(groups.values(), key=group_score)
                                                                              
                                                            
    sx0=min(stats[i,cv2.CC_STAT_LEFT] for i in selected); sy0=min(stats[i,cv2.CC_STAT_TOP] for i in selected)
    sx1=max(stats[i,cv2.CC_STAT_LEFT]+stats[i,cv2.CC_STAT_WIDTH] for i in selected)
    sy1=max(stats[i,cv2.CC_STAT_TOP]+stats[i,cv2.CC_STAT_HEIGHT] for i in selected)
    selected_area=sum(stats[i,cv2.CC_STAT_AREA] for i in selected)
    for group in groups.values():
        if group is selected: continue
        area=sum(stats[i,cv2.CC_STAT_AREA] for i in group)
        gx0_=min(stats[i,cv2.CC_STAT_LEFT] for i in group); gy0_=min(stats[i,cv2.CC_STAT_TOP] for i in group)
        gx1_=max(stats[i,cv2.CC_STAT_LEFT]+stats[i,cv2.CC_STAT_WIDTH] for i in group)
        gy1_=max(stats[i,cv2.CC_STAT_TOP]+stats[i,cv2.CC_STAT_HEIGHT] for i in group)
        gapx=max(0,max(sx0,gx0_)-min(sx1,gx1_)); gapy=max(0,max(sy0,gy0_)-min(sy1,gy1_))
        if area >= .080*selected_area and gapx <= .09*mask.shape[1] and gapy <= .09*mask.shape[0]:
            selected += group
    major = selected
    gx0 = min(stats[i, cv2.CC_STAT_LEFT] for i in major)
    gy0 = min(stats[i, cv2.CC_STAT_TOP] for i in major)
    gx1 = max(stats[i, cv2.CC_STAT_LEFT] + stats[i, cv2.CC_STAT_WIDTH] for i in major)
    gy1 = max(stats[i, cv2.CC_STAT_TOP] + stats[i, cv2.CC_STAT_HEIGHT] for i in major)
    gx0, gx1 = gx0 - mask.shape[1] * .12, gx1 + mask.shape[1] * .12
    gy0, gy1 = gy0 - mask.shape[0] * .12, gy1 + mask.shape[0] * .12
    adaptive_min = max(min_area, round(largest * .003))
    for i in candidates:
        x, y, w, h, area = stats[i]
        near_glyph = x < gx1 and x + w > gx0 and y < gy1 and y + h > gy0
        if area >= adaptive_min and near_glyph:
            result[labels == i] = 255
    return result


def isolate_raw(crop: np.ndarray, detected_mask: np.ndarray, retained_mask: np.ndarray) -> np.ndarray:

    protected = cv2.dilate(retained_mask, np.ones((3, 3), np.uint8), iterations=1)
    rejected_all = ((detected_mask > 0) & (protected == 0)).astype(np.uint8) * 255
                                                                             
                                                                               
    rejected = cv2.dilate(rejected_all, np.ones((5, 5), np.uint8), iterations=1)
    if not np.any(rejected):
        return crop.copy()
    return cv2.inpaint(crop, rejected, 5, cv2.INPAINT_TELEA)


def gray_output(crop: np.ndarray, mask: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    output = np.full_like(gray, 255)
    output[mask > 0] = clahe[mask > 0]
    return output


def boxes_for_grid(box: tuple[int, int, int, int], layout: Layout):
    x0, y0, x1, y1 = inset_box(box, layout)
    cw, ch = (x1 - x0) / layout.cols, (y1 - y0) / layout.rows
    for physical_col in range(layout.cols):
        logical_col = layout.cols - physical_col                                        
        for row0 in range(layout.rows):
            core_x0 = x0 + physical_col * cw
            core_x1 = x0 + (physical_col + 1) * cw
            core_y0 = y0 + row0 * ch
            core_y1 = y0 + (row0 + 1) * ch
            px, py = layout.crop_pad * cw, layout.crop_pad * ch
            bx0 = max(box[0], math.floor(core_x0 - px))
            by0 = max(box[1], math.floor(core_y0 - py))
            bx1 = min(box[2], math.ceil(core_x1 + px))
            by1 = min(box[3], math.ceil(core_y1 + py))
            core_local = (round(core_x0 - bx0), round(core_y0 - by0),
                          round(core_x1 - bx0), round(core_y1 - by0))
            yield logical_col, row0 + 1, (bx0, by0, bx1, by1), core_local


def contact_sheet(items: list[tuple[str, np.ndarray]], columns: int = 8, tile: int = 160) -> np.ndarray:
    rows = max(1, math.ceil(len(items) / columns))
    sheet = np.full((rows * (tile + 28), columns * tile, 3), 255, np.uint8)
    for index, (label, image) in enumerate(items):
        r, c = divmod(index, columns)
        thumb = fit_canvas(image, tile, (255, 255, 255))
        sheet[r * (tile + 28):r * (tile + 28) + tile, c * tile:(c + 1) * tile] = thumb
        cv2.putText(sheet, label, (c * tile + 4, r * (tile + 28) + tile + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, .42, (20, 20, 20), 1, cv2.LINE_AA)
    return sheet


def process(input_root: Path, output_root: Path, writers: list[str], preview: bool, size: int) -> None:
    (output_root / "metadata").mkdir(parents=True, exist_ok=True)
    glyph_rows, page_rows = [], []
    for writer in writers:
        layout = LAYOUTS[writer]
        folder = input_root / writer
        images = sorted([p for p in folder.iterdir() if p.suffix.lower() in IMAGE_EXTENSIONS], key=natural_key)
        if preview and images:
            indices = sorted(set([0, len(images) // 2, len(images) - 1]))
            images = [images[i] for i in indices]
        for page_index, path in enumerate(images, start=1):
            image = read_image(path)
            panels = panel_boxes(image, writer, layout)
            overlay = image.copy()
            page_items = []
            saved = 0
            for panel_index, panel in enumerate(panels, start=1):
                grid = inset_box(panel, layout)
                cv2.rectangle(overlay, panel[:2], panel[2:], (255, 0, 255), 3)
                cv2.rectangle(overlay, grid[:2], grid[2:], (0, 170, 0), 3)
                for col, row, bbox, core in boxes_for_grid(panel, layout):
                    bx0, by0, bx1, by1 = bbox
                    crop = image[by0:by1, bx0:bx1].copy()
                    raw_mask = ink_mask(crop)
                    mask = retain_character(raw_mask, core)
                    ink_ratio = float(np.count_nonzero(mask)) / mask.size
                    is_blank = ink_ratio < 0.0010
                    color = (160, 160, 160) if is_blank else (0, 0, 255)
                    cv2.rectangle(overlay, (bx0, by0), (bx1, by1), color, 2)
                    logical_page = int(path.stem) if path.stem.isdigit() else page_index
                    glyph_id = f"{writer}_p{logical_page:03d}_s{panel_index:02d}_c{col:02d}_r{row:02d}"
                    if not is_blank:
                        isolated_crop = isolate_raw(crop, raw_mask, mask)
                        raw_canvas = fit_canvas(isolated_crop, size, (255, 255, 255))
                        mask_canvas = fit_canvas(255 - mask, size, 255)
                        gray_canvas = fit_canvas(gray_output(crop, mask), size, 255)
                        writer_root = output_root / writer
                        write_image(writer_root / "raw_color" / f"{glyph_id}.png", raw_canvas)
                        write_image(writer_root / "gray" / f"{glyph_id}.png", gray_canvas)
                        write_image(writer_root / "gray_enhanced" / f"{glyph_id}.png", gray_canvas)
                        write_image(writer_root / "mask" / f"{glyph_id}.png", mask_canvas)
                        foreground = mask_canvas < 128
                        edge = foreground ^ cv2.erode(foreground.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
                        skeleton = cv2.ximgproc.thinning((foreground.astype(np.uint8) * 255)) if hasattr(cv2, "ximgproc") else edge.astype(np.uint8) * 255
                        write_image(writer_root / "edge" / f"{glyph_id}.png", np.where(edge, 0, 255).astype(np.uint8))
                        write_image(writer_root / "skeleton" / f"{glyph_id}.png", 255 - skeleton)
                        page_items.append((f"s{panel_index} c{col} r{row}", raw_canvas))
                        saved += 1
                    glyph_rows.append({
                        "glyph_id": glyph_id, "writer": writer, "source_file": str(path),
                        "source_page": logical_page, "panel": panel_index, "column_rtl": col,
                        "row": row, "x0": bx0, "y0": by0, "x1": bx1, "y1": by1,
                        "ink_ratio": f"{ink_ratio:.6f}", "is_blank": int(is_blank),
                        "saved": int(not is_blank), "character": "", "original_glyph_id": "",
                        "pair_confirmed": 0,
                    })
            preview_dir = output_root / "comparison" / writer
            write_image(preview_dir / f"{path.stem}_boxes.jpg", overlay)
            write_image(preview_dir / f"{path.stem}_glyphs.jpg", contact_sheet(page_items))
            page_rows.append({"writer": writer, "source_file": str(path), "panels": len(panels),
                              "candidate_cells": len(panels) * layout.cols * layout.rows,
                              "saved_glyphs": saved, "rows": layout.rows, "cols_per_panel": layout.cols})
            print(f"{writer} {path.name}: {saved} glyphs")

    if glyph_rows:
        with (output_root / "metadata" / "glyphs.csv").open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(glyph_rows[0]))
            writer.writeheader(); writer.writerows(glyph_rows)
    if page_rows:
        with (output_root / "metadata" / "pages.csv").open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(page_rows[0]))
            writer.writeheader(); writer.writerows(page_rows)
    config = {name: vars(layout) for name, layout in LAYOUTS.items() if name in writers}
    (output_root / "metadata" / "layout_config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Complete-cell cutter for Yanta Shengjiao Xu handwritten copies")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--writers", nargs="*", default=list(LAYOUTS))
    parser.add_argument("--preview", action="store_true", help="first/middle/last page for each writer")
    parser.add_argument("--size", type=int, default=256)
    args = parser.parse_args()
    writers = [w for w in args.writers if w in LAYOUTS and (args.input / w).exists()]
    process(args.input, args.output, writers, args.preview, args.size)


if __name__ == "__main__":
    main()
