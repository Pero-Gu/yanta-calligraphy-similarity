from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import cv2
import numpy as np
import pandas as pd


def read_image(path: Path, mode: int) -> np.ndarray:
    image = cv2.imdecode(np.fromfile(str(path), np.uint8), mode)
    if image is None:
        raise FileNotFoundError(path)
    return image


def component_stats(mask: np.ndarray, min_area: int = 20):
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    result = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area >= min_area:
            result.append((int(area), int(x), int(y), int(w), int(h)))
    return sorted(result, reverse=True)


def audit_one(raw: np.ndarray, mask_image: np.ndarray) -> dict:
    foreground = mask_image < 128
    points = cv2.findNonZero(foreground.astype(np.uint8))
    if points is None:
        return {"mask_pixels": 0, "empty_mask": 1, "severity": 100,
                "flags": "empty_mask"}
    x, y, w, h = cv2.boundingRect(points)
    gray = cv2.cvtColor(raw, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(raw, cv2.COLOR_BGR2HSV)
                                                                               
                                                                            
    raw_black = gray < 125
    explained = cv2.dilate(foreground.astype(np.uint8), np.ones((7, 7), np.uint8), 1) > 0
    unexplained = raw_black & ~explained
    unexplained_components = component_stats(unexplained, 20)
    max_unexplained = unexplained_components[0][0] if unexplained_components else 0
    unexplained_total = sum(item[0] for item in unexplained_components)
    ink_pixels = int(foreground.sum())
    ratio = unexplained_total / max(1, ink_pixels)
    b, g, r = cv2.split(raw)
    red = (((hsv[:, :, 0] < 12) | (hsv[:, :, 0] > 175)) &
           (hsv[:, :, 1] > 120) & (r.astype(np.int16) > g.astype(np.int16) + 35) &
           (r.astype(np.int16) > b.astype(np.int16) + 35))
    red_ratio = float(red.mean())

                                                                             
                                                                              
                                                                               
    paper = gray < 248
    paper_points = cv2.findNonZero(paper.astype(np.uint8))
    raw_edge_sides = []
    raw_edge_counts = {"left": 0, "top": 0, "right": 0, "bottom": 0}
    if paper_points is not None:
        px, py, pw, ph = cv2.boundingRect(paper_points)
        edge_width = 5
        raw_edge_counts["left"] = int(raw_black[py:py + ph, px:px + edge_width].sum())
        raw_edge_counts["right"] = int(raw_black[py:py + ph, px + pw - edge_width:px + pw].sum())
        raw_edge_counts["top"] = int(raw_black[py:py + edge_width, px:px + pw].sum())
        raw_edge_counts["bottom"] = int(raw_black[py + ph - edge_width:py + ph, px:px + pw].sum())
        raw_edge_sides = [side for side, count in raw_edge_counts.items() if count >= 12]

                                                                            
                                                                         
    sides = []
    if x <= 9: sides.append("left")
    if y <= 9: sides.append("top")
    if x + w >= 247: sides.append("right")
    if y + h >= 247: sides.append("bottom")
    flags = []
    if sides: flags.append("crop_edge:" + "+".join(sides))
    if raw_edge_sides: flags.append("raw_ink_at_content_edge:" + "+".join(raw_edge_sides))
    if max_unexplained >= 220 or ratio >= .18: flags.append("large_unexplained_black")
    if red_ratio >= .015: flags.append("red_seal_or_annotation")
    if ink_pixels < 80: flags.append("very_small_foreground")
                                                              
    severity = (25 * len(sides) + 30 * len(raw_edge_sides) + min(25, max_unexplained / 12) +
                min(25, ratio * 100) + min(20, red_ratio * 250))
    return {
        "mask_pixels": ink_pixels, "mask_bbox_x": x, "mask_bbox_y": y,
        "mask_bbox_w": w, "mask_bbox_h": h, "crop_edge_sides": "+".join(sides),
        "unexplained_component_count": len(unexplained_components),
        "max_unexplained_component": max_unexplained,
        "unexplained_to_mask_ratio": ratio, "red_ratio": red_ratio,
        "raw_edge_sides": "+".join(raw_edge_sides),
        "raw_edge_left_pixels": raw_edge_counts["left"],
        "raw_edge_top_pixels": raw_edge_counts["top"],
        "raw_edge_right_pixels": raw_edge_counts["right"],
        "raw_edge_bottom_pixels": raw_edge_counts["bottom"],
        "empty_mask": 0, "severity": severity, "flags": ";".join(flags),
    }


def montage(items, output: Path, columns: int = 6, tile: int = 180):
    if not items:
        return
    rows = math.ceil(len(items) / columns)
    canvas = np.full((rows * (tile + 42), columns * tile, 3), 255, np.uint8)
    for index, (label, image) in enumerate(items):
        r, c = divmod(index, columns)
        thumb = cv2.resize(image, (tile, tile), interpolation=cv2.INTER_AREA)
        y, x = r * (tile + 42), c * tile
        canvas[y:y + tile, x:x + tile] = thumb
        cv2.putText(canvas, label[:25], (x + 3, y + tile + 17),
                    cv2.FONT_HERSHEY_SIMPLEX, .38, (0, 0, 0), 1, cv2.LINE_AA)
    output.parent.mkdir(parents=True, exist_ok=True)
    cv2.imencode(".jpg", canvas, [cv2.IMWRITE_JPEG_QUALITY, 92])[1].tofile(str(output))


def main():
    parser = argparse.ArgumentParser(description="Read-only QA audit of handwritten glyph cuts")
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--montage-limit", type=int, default=72)
    args = parser.parse_args()
    metadata = pd.read_csv(args.dataset / "metadata" / "glyphs.csv")
    metadata = metadata[metadata["saved"] == 1]
    rows = []
    montage_candidates = {}
    for _, source in metadata.iterrows():
        writer, gid = source["writer"], source["glyph_id"]
        raw_path = args.dataset / writer / "raw_color" / f"{gid}.png"
        mask_path = args.dataset / writer / "mask" / f"{gid}.png"
        raw = read_image(raw_path, cv2.IMREAD_COLOR)
        mask = read_image(mask_path, cv2.IMREAD_GRAYSCALE)
        result = audit_one(raw, mask)
        row = {"glyph_id": gid, "writer": writer, "raw_path": str(raw_path),
               "mask_path": str(mask_path), **result}
        rows.append(row)
        if result["flags"]:
            label = f"{gid.split('_', 1)[-1]} {result['flags']}"
            montage_candidates.setdefault(writer, []).append((result["severity"], label, raw))
    args.output.mkdir(parents=True, exist_ok=True)
    details = args.output / "cut_audit_details.csv"
    with details.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    frame = pd.DataFrame(rows)
    summary = []
    for writer, group in frame.groupby("writer"):
        summary.append({
            "writer": writer, "total": len(group),
            "any_flag": int((group["flags"] != "").sum()),
            "crop_edge": int(group["flags"].str.contains("crop_edge").sum()),
            "raw_ink_at_content_edge": int(group["flags"].str.contains("raw_ink_at_content_edge").sum()),
            "large_unexplained_black": int(group["flags"].str.contains("large_unexplained_black").sum()),
            "red_seal_or_annotation": int(group["flags"].str.contains("red_seal_or_annotation").sum()),
            "very_small_foreground": int(group["flags"].str.contains("very_small_foreground").sum()),
        })
    pd.DataFrame(summary).to_csv(args.output / "cut_audit_summary.csv", index=False, encoding="utf-8-sig")
    for writer, candidates in montage_candidates.items():
        candidates.sort(reverse=True, key=lambda item: item[0])
        montage([(label, image) for _, label, image in candidates[:args.montage_limit]],
                args.output / f"{writer}_flagged.jpg")
    print(pd.DataFrame(summary).to_string(index=False))
    print(f"details={details}")


if __name__ == "__main__":
    main()
