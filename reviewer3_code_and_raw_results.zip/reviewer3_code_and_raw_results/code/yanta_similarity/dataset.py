from __future__ import annotations

from pathlib import Path
import hashlib
import cv2
import numpy as np
import pandas as pd
from torch.utils.data import Dataset

from .features import read_gray, foreground_from_mask, pair_tensors
from .perturbations import controlled_perturb, KINDS


def split_name(glyph_id: str, seed: int) -> str:
    value = int(hashlib.sha256(f"{seed}:{glyph_id}".encode()).hexdigest()[:8], 16) % 100
    return "train" if value < 70 else "val" if value < 85 else "test"


class ControlledOriginalDataset(Dataset):
    def __init__(self, metadata: str, gray_dir: str, mask_dir: str, split: str, seed: int,
                 samples_per_glyph: int = 2, limit: int | None = None, exhaustive: bool = False,
                 split_seed: int | None = None):
        frame = pd.read_csv(metadata)
        if "saved" in frame: frame = frame[frame.saved.astype(str).str.lower().isin(["true", "1"])]
        frame = frame[frame.glyph_id.map(lambda x: split_name(str(x), split_seed if split_seed is not None else seed) == split)].reset_index(drop=True)
        if limit: frame = frame.iloc[:limit]
        self.frame, self.gray_dir, self.mask_dir = frame, Path(gray_dir), Path(mask_dir)
        self.seed, self.samples_per_glyph, self.epoch, self.exhaustive = seed, samples_per_glyph, 0, exhaustive

    def set_epoch(self, epoch): self.epoch = int(epoch)
    def __len__(self): return len(self.frame) * (22 if self.exhaustive else self.samples_per_glyph)

    def __getitem__(self, index):
        stride=22 if self.exhaustive else self.samples_per_glyph
        row = self.frame.iloc[index // stride]
        glyph_id = str(row.glyph_id)
        gray = read_gray(self.gray_dir / f"{glyph_id}.png")
        mask_img = read_gray(self.mask_dir / f"{glyph_id}.png")
        mask = foreground_from_mask(mask_img)
        if self.exhaustive:
            local=index%22
            if local==0: kind,severity="allowed",0.0
            elif local==21: kind,severity="different",1.0
            else: kind=KINDS[1+(local-1)//4];severity=(.25,.5,.75,1.)[(local-1)%4]
                                                                                      
            group=0 if local==0 else 6 if local==21 else 1+(local-1)//4
            rng=np.random.default_rng(self.seed+(index//22)*1009+group*9176)
        else:
            rng = np.random.default_rng(self.seed + self.epoch * 1000003 + index)
            kind = KINDS[int(rng.integers(0, len(KINDS)))]
            severity = 0.0 if kind == "allowed" else float(rng.choice([.25, .5, .75, 1.0]))
        if kind == "different":
            glyph_index=index//stride;offset=1+int(rng.integers(0,min(12,max(1,len(self.frame)-1))))
            other=self.frame.iloc[(glyph_index+offset)%len(self.frame)];other_id=str(other.glyph_id)
            candidate=read_gray(self.gray_dir/f"{other_id}.png");candidate_mask=foreground_from_mask(read_gray(self.mask_dir/f"{other_id}.png"));target=np.zeros(5,np.float32)
        else:
            candidate, candidate_mask, target = controlled_perturb(gray, mask, kind, severity, rng)
        out = pair_tensors(gray, mask, candidate, candidate_mask)
        out.update(target=np.asarray(target), severity=np.float32(severity), kind=kind, glyph_id=glyph_id)
        return out


def read_pair(gray_path, mask_path):
    gray = read_gray(gray_path); mask = foreground_from_mask(read_gray(mask_path))
    return gray, mask
