from __future__ import annotations
import numpy as np


def monotonic_alignment(similarity: np.ndarray, gap: float = -.2):

    n,m=similarity.shape; dp=np.full((n+1,m+1),-np.inf,np.float32); back=np.zeros((n+1,m+1),np.int8); dp[0,0]=0
    for i in range(1,n+1): dp[i,0]=0; back[i,0]=1                        
    for j in range(1,m+1): dp[0,j]=dp[0,j-1]+gap; back[0,j]=2
    for i in range(1,n+1):
        for j in range(1,m+1):
            choices=(dp[i-1,j-1]+similarity[i-1,j-1],dp[i-1,j]+gap,dp[i,j-1]+gap)
            back[i,j]=int(np.argmax(choices)); dp[i,j]=choices[back[i,j]]
    pairs=[]; i,j=int(np.argmax(dp[:,m])),m                        
    while j:
        b=back[i,j]
        if b==0: pairs.append((i-1,j-1,float(similarity[i-1,j-1]))); i-=1; j-=1
        elif b==1: i-=1
        else: j-=1
    return list(reversed(pairs))


def assess_pair(sim: np.ndarray, i: int, j: int, threshold=.30, margin=.01, window=8):
    value=float(sim[i,j]); row0,row1=max(0,j-window),min(sim.shape[1],j+window+1);col0,col1=max(0,i-window),min(sim.shape[0],i+window+1)
    row=sim[i,row0:row1];col=sim[col0:col1,j]
    row_second=float(np.partition(row,-2)[-2]) if len(row)>1 else -1
    col_second=float(np.partition(col,-2)[-2]) if len(col)>1 else -1
    mutual=row0+int(np.argmax(row))==j and col0+int(np.argmax(col))==i
    advantage=value-max(row_second,col_second)
    if value<threshold: return value,False,"low_similarity"
    if not mutual: return value,False,"not_bidirectional_nearest"
    if advantage<margin: return value,False,"insufficient_local_advantage"
    return min(1.,max(0.,.7*value+.3*min(1.,max(0.,advantage/.2)))),True,""
