from __future__ import annotations

import cv2
import numpy as np


NAMES = ("layout", "stroke_geometry", "width_ink", "topology", "deep_visual")
KINDS = ("allowed", "layout", "stroke_geometry", "width_ink", "topology", "combined", "different")


def _warp(a, matrix, interp, border):
    h, w = a.shape
    return cv2.warpAffine(a, matrix, (w, h), flags=interp, borderValue=border)


def controlled_perturb(gray: np.ndarray, mask: np.ndarray, kind: str, severity: float,
                       rng: np.random.Generator):

    g, m = gray.copy(), mask.astype(np.uint8).copy()
    h, w = g.shape
                                                            
    angle = rng.uniform(-5, 5); scale = rng.uniform(.93, 1.07)
    dx, dy = rng.uniform(-.05, .05) * w, rng.uniform(-.05, .05) * h
    mat = cv2.getRotationMatrix2D((w / 2, h / 2), angle, scale); mat[:, 2] += (dx, dy)
    g = _warp(g, mat, cv2.INTER_LINEAR, 255); m = _warp(m, mat, cv2.INTER_NEAREST, 0)
    g = np.clip(g.astype(np.float32) * rng.uniform(.94, 1.06), 0, 255).astype(np.uint8)
    target = np.ones(5, np.float32)
    s = float(np.clip(severity, 0, 1))
    if kind == "allowed" or s == 0:
        return g, m.astype(bool), target
    if kind in ("layout", "combined"):
                                                                               
        split = w // 2
        part = m[:, split:].copy()
        shift = int(round((.04 + .12 * s) * w)) * (-1 if rng.random() < .5 else 1)
        moved = np.zeros_like(part)
        if shift >= 0: moved[:, min(shift, part.shape[1]):] = part[:, :max(0, part.shape[1]-shift)]
        else: moved[:, :shift] = part[:, -shift:]
        m[:, split:] = moved
        target[0] = 1 - .75 * s
    if kind in ("stroke_geometry", "combined"):
        k = max(1, int(round(1 + 4 * s)))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k * 2 + 1, 3))
        m = cv2.erode(m, kernel, iterations=1) if rng.random() < .5 else cv2.dilate(m, kernel, iterations=1)
        target[1] = 1 - .8 * s
    if kind in ("width_ink", "combined"):
        k = 1 + int(1 + 3 * s)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*k+1, 2*k+1))
        m = cv2.dilate(m, kernel) if rng.random() < .5 else cv2.erode(m, kernel)
        target[2] = 1 - .85 * s
    if kind in ("topology", "combined"):
                                                                             
        ys, xs = np.where(m > 0)
        if len(xs):
            if rng.random() < .5:
                x = int(np.quantile(xs, rng.uniform(.3, .7))); radius = 1 + int(4*s)
                m[:, max(0, x-radius):min(w, x+radius+1)] = 0
            else:
                y = int(np.quantile(ys, rng.uniform(.3, .7))); radius = 1 + int(4*s)
                m[max(0, y-radius):min(h, y+radius+1), :] = 0
        target[3] = 1 - .95 * s
    if kind == "combined":
        target[4] = 1 - .65 * s
                                                                                            
    ink_level = np.where(m > 0, np.minimum(g, 80 + int(90*s)), 255)
    return ink_level.astype(np.uint8), m.astype(bool), np.clip(target, 0, 1)
