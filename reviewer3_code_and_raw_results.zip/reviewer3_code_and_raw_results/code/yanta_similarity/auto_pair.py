from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F

from .config import load_config, refuse_forbidden_path, json_dump
from .features import read_gray, image_tensor
from .pairing import monotonic_alignment, assess_pair
from .runtime import locate, load_checkpoint


def _embed(model, paths, device, batch_size=24):
    result=[]
    for start in range(0,len(paths),batch_size):
        batch=torch.stack([image_tensor(read_gray(p)) for p in paths[start:start+batch_size]]).to(device)
        with torch.no_grad(): _,global_token=model.backbone(batch);global_token=model.adapter(global_token)
        result.append(F.normalize(global_token,dim=1))
    return torch.cat(result) if result else torch.empty((0,model.backbone.embed_dim),device=device)


def _orders(frame, handwritten=False):
    if handwritten:
        cols=[c for c in ("source_page","panel","column_rtl","row") if c in frame]
        ascending=[True,True,True,True][:len(cols)]
    else:
        cols=[c for c in ("page","panel","column_right_to_left","row_top_to_bottom") if c in frame]
        ascending=[True]*len(cols)
    return frame.sort_values(cols,ascending=ascending).reset_index(drop=True)


def _truthy(series):
    text=series.astype(str).str.strip().str.lower()
    numeric=pd.to_numeric(series,errors="coerce").fillna(0)
    return text.isin(["true","yes","pass"]) | (numeric>0)


def run(config_path):
    cfg=load_config(config_path); hand=cfg["data"]["handwritten_root"]
    refuse_forbidden_path(hand,cfg)
    hm=Path(hand)/"metadata"/"glyphs.csv"
    if not hm.exists(): raise FileNotFoundError(f"V3 metadata not found: {hm}. Complete V3 cutting audit first.")
    original=_orders(pd.read_csv(cfg["data"]["original_metadata"])); handwritten=_orders(pd.read_csv(hm),True)
    if "saved" in original: original=original[_truthy(original.saved)]
    if "saved" in handwritten: handwritten=handwritten[_truthy(handwritten.saved)]
    if "usable" in handwritten: handwritten=handwritten[_truthy(handwritten.usable)]
    if "cut_quality" in handwritten: handwritten=handwritten[handwritten.cut_quality.astype(str).str.lower()=="pass"]
    original=original.reset_index(drop=True); handwritten=handwritten.reset_index(drop=True)
    if handwritten.empty: raise RuntimeError("No usable V3 glyphs remained after quality filtering")
    checkpoint=cfg["pairing"].get("checkpoint") or str(Path(cfg["output"]["training_dir"])/"best.pt")
    if not Path(checkpoint).exists(): raise FileNotFoundError(f"Trained checkpoint not found: {checkpoint}")
    model,_,device=load_checkpoint(checkpoint)
    opaths=[Path(cfg["data"]["original_gray"])/f"{x}.png" for x in original.glyph_id]
    rows=[]; metrics={}
    oe=_embed(model,opaths,device)
    for writer,hf in handwritten.groupby("writer",sort=False):
        hf=hf.reset_index(drop=True); hpaths=[locate(hand,writer,"gray_enhanced",x) for x in hf.glyph_id]
        he=_embed(model,hpaths,device); sim=(oe@he.T).float().cpu().numpy(); aligned=monotonic_alignment(sim,float(cfg["pairing"].get("gap_penalty",-.2)))
        used=0; mutual=0
        for k,(i,j,_) in enumerate(aligned,1):
            confidence,usable,reason=assess_pair(sim,i,j,float(cfg["pairing"]["similarity_threshold"]),float(cfg["pairing"]["margin_threshold"]))
            mutual += int(reason!="not_bidirectional_nearest"); used += int(usable)
            rows.append({"pair_id":f"{writer}_{k:05d}","character_index":k,"writer":writer,
                "original_id":original.iloc[i].glyph_id,"handwritten_id":hf.iloc[j].glyph_id,
                "pair_confidence":confidence,"cut_quality":"pass","usable":usable,"reject_reason":reason})
        metrics[str(writer)]={"candidates":len(aligned),"usable":used,"coverage":used/max(1,min(len(original),len(hf))),
                              "rejection_rate":1-used/max(1,len(aligned)),"bidirectional_consistency":mutual/max(1,len(aligned)),
                              "recall_at_1":None,"recall_at_5":None,"mrr":None,"retrieval_note":"requires verified same-character ground truth"}
    output=Path(cfg["output"]["pairing_csv"]); output.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(output,index=False,encoding="utf-8-sig"); json_dump(metrics,output.with_suffix(".report.json")); return output


def main():
    p=argparse.ArgumentParser();p.add_argument("--config",required=True);a=p.parse_args();print(run(a.config))
if __name__=="__main__":main()
