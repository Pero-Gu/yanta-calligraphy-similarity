from __future__ import annotations
import argparse
from pathlib import Path
import cv2
import numpy as np
import pandas as pd
import torch

from .dataset import read_pair
from .features import pair_tensors, edge_map, skeleton_map
from .runtime import load_checkpoint, locate


def _batch(x,device): return {k:v.unsqueeze(0).to(device) for k,v in x.items()}


def _shared_tta(gray,mask,index):
    if index==0:return gray,mask
    h,w=gray.shape; angles=(0,-2,2,0,0,-1,1,0); shifts=((0,0),(0,0),(0,0),(2,0),(-2,0),(0,2),(0,-2),(1,1))
    mat=cv2.getRotationMatrix2D((w/2,h/2),angles[index],1.0);mat[:,2]+=shifts[index]
    return (cv2.warpAffine(gray,mat,(w,h),flags=cv2.INTER_LINEAR,borderValue=255),
            cv2.warpAffine(mask.astype(np.uint8),mat,(w,h),flags=cv2.INTER_NEAREST,borderValue=0).astype(bool))


def _save_explanation(outdir,pair_id,og,om,hg,hm,token_diff):
    folder=Path(outdir)/pair_id;folder.mkdir(parents=True,exist_ok=True)
    cv2.imencode(".png",og)[1].tofile(folder/"original.png");cv2.imencode(".png",hg)[1].tofile(folder/"handwritten.png")
    canvas=np.full((*og.shape,3),255,np.uint8); canvas[edge_map(om)]=(0,0,255)
    resized_hm=cv2.resize(hm.astype(np.uint8),(og.shape[1],og.shape[0]),interpolation=cv2.INTER_NEAREST).astype(bool)
    canvas[edge_map(resized_hm)]=(255,0,0);cv2.imencode(".png",canvas)[1].tofile(folder/"contour_overlay.png")
    sk=np.zeros_like(canvas);sk[skeleton_map(om)]=(0,0,255);sk[skeleton_map(resized_hm)]=(255,0,0)
    cv2.imencode(".png",sk)[1].tofile(folder/"skeleton_difference.png")
    td=np.asarray(token_diff,np.float32);td=cv2.resize(td,(og.shape[1],og.shape[0]));td=cv2.normalize(td,None,0,255,cv2.NORM_MINMAX).astype(np.uint8)
    heat=cv2.applyColorMap(td,cv2.COLORMAP_TURBO);cv2.imencode(".png",heat)[1].tofile(folder/"dino_difference.png")
    return str((folder/"dino_difference.png").resolve())


def run(checkpoint_path,pairs_path,explain=False,output_dir=None):
    model,checkpoint,device=load_checkpoint(checkpoint_path);cfg=checkpoint["config"];pairs=pd.read_csv(pairs_path)
    outdir=Path(output_dir or cfg["output"]["score_dir"]);outdir.mkdir(parents=True,exist_ok=True);rows=[]
    for _,r in pairs.iterrows():
        base={"pair_id":r.pair_id,"writer":r.writer,"original_id":r.original_id,"handwritten_id":r.handwritten_id,
              "pair_confidence":float(r.pair_confidence),"reject_reason":str(r.get("reject_reason","") or "")}
        if str(r.get("usable",True)).lower() not in ("true","1"):
            rows.append({**base,**{k:np.nan for k in ("layout_score","stroke_geometry_score","width_ink_score","topology_score","deep_visual_score","total_similarity","uncertainty")},"quality_status":"rejected","heatmap_path":""});continue
        op=Path(cfg["data"]["original_gray"])/f"{r.original_id}.png";omp=Path(cfg["data"]["original_mask"])/f"{r.original_id}.png"
        hp=locate(cfg["data"]["handwritten_root"],r.writer,"gray_enhanced",r.handwritten_id);hmp=locate(cfg["data"]["handwritten_root"],r.writer,"mask",r.handwritten_id)
        og,om=read_pair(op,omp);hg,hm=read_pair(hp,hmp);outputs=[]
        with torch.no_grad():
            for t in range(8):
                oga,oma=_shared_tta(og,om,t);hga,hma=_shared_tta(hg,hm,t)
                outputs.append(model(_batch(pair_tensors(oga,oma,hga,hma),device)))
        scores=torch.cat([x["scores"] for x in outputs]);totals=torch.cat([x["total"] for x in outputs])
        mean=scores.mean(0); identical=og.shape==hg.shape and np.array_equal(og,hg) and np.array_equal(om,hm)
        if identical: mean[:]=1; total=100.;uncertainty=0.
        else:
            total=float((mean*outputs[0]["fusion_weights"]).sum()*100)
            uncertainty=float(100*(totals.var(unbiased=False)+scores.mean(0).std(unbiased=False)*.35+(1-float(r.pair_confidence))*.15))
        rejected=uncertainty>float(cfg["scoring"]["max_uncertainty"])
        heatpath=_save_explanation(outdir/"explanations",str(r.pair_id),og,om,hg,hm,outputs[0]["token_difference"][0].cpu()) if explain else ""
        vals=(mean.cpu().numpy()*100).tolist()
        rows.append({**base,"layout_score":vals[0],"stroke_geometry_score":vals[1],"width_ink_score":vals[2],
            "topology_score":vals[3],"deep_visual_score":vals[4],"total_similarity":np.nan if rejected else total,
            "uncertainty":uncertainty,"quality_status":"rejected_high_uncertainty" if rejected else "accepted",
            "reject_reason":"high_uncertainty" if rejected else "","heatmap_path":heatpath})
    output=outdir/"scores.csv";pd.DataFrame(rows).to_csv(output,index=False,encoding="utf-8-sig");return output


def main():
    p=argparse.ArgumentParser();p.add_argument("--checkpoint",required=True);p.add_argument("--pairs",required=True);p.add_argument("--explain",action="store_true");p.add_argument("--output");a=p.parse_args();print(run(a.checkpoint,a.pairs,a.explain,a.output))
if __name__=="__main__":main()
