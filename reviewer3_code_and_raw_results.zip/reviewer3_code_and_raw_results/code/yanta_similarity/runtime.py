from __future__ import annotations
from pathlib import Path
import torch
from .model import YantaSimilarityNet


def load_checkpoint(path, device=None):
    device=device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint=torch.load(path,map_location=device,weights_only=False)
    model=YantaSimilarityNet(checkpoint["config"]["backbone"], checkpoint["config"].get("ablations")).to(device)
    model.load_state_dict(checkpoint["model_state"]); model.eval()
    return model,checkpoint,device


def locate(root, writer, subdir, glyph_id):
    options=[Path(root)/str(writer)/subdir/f"{glyph_id}.png",Path(root)/subdir/f"{glyph_id}.png"]
    for p in options:
        if p.exists(): return p
    raise FileNotFoundError(options[0])
