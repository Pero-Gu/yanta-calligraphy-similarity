from __future__ import annotations
import torch
import torch.nn.functional as F


def info_nce(a, b, temperature=.1):
    a, b = F.normalize(a, dim=1), F.normalize(b, dim=1)
    labels = torch.arange(a.shape[0], device=a.device)
    return (F.cross_entropy(a @ b.T / temperature, labels) + F.cross_entropy(b @ a.T / temperature, labels)) / 2


def objective_loss(output, target, severity):
    scores, total = output["scores"], output["total"]
    smooth = F.smooth_l1_loss(scores, target)
    expected_total = target.mean(1)
                                                                                    
    delta_s = severity[:, None] - severity[None, :]
    delta_p = total[:, None] - total[None, :]
    ranking = torch.relu(.03 + delta_p)[delta_s > .2].mean() if (delta_s > .2).any() else total.new_zeros(())
    allowed = severity == 0
    invariance = F.smooth_l1_loss(scores[allowed], torch.ones_like(scores[allowed])) if allowed.any() else total.new_zeros(())
    contrast = info_nce(output["original_embedding"], output["candidate_embedding"])
    monotonic = F.smooth_l1_loss(total, expected_total)
    entropy = (output["fusion_weights"] * torch.log(output["fusion_weights"] + 1e-8)).sum()
    loss = smooth + ranking + .5*invariance + .25*contrast + .5*monotonic + .01*entropy
    return loss, {"smooth_l1": smooth, "ranking": ranking, "invariance": invariance,
                  "info_nce": contrast, "fusion_monotonic": monotonic}
