from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision.models import resnet18, ResNet18_Weights

from .config import json_dump
from .dataset import ControlledOriginalDataset
from .metrics import controlled_metrics
from .runtime import load_checkpoint


def _record(store,name,batch,i,value):
    store[name].append({"glyph_id":batch["glyph_id"][i],"kind":batch["kind"][i],"severity":float(batch["severity"][i]),"scores":[value]*5,"total":value})


def run(checkpoint_path, ablations=()):
    model,ckpt,device=load_checkpoint(checkpoint_path);cfg=ckpt["config"]
    ds=ControlledOriginalDataset(cfg["data"]["original_metadata"],cfg["data"]["original_gray"],cfg["data"]["original_mask"],
        "test",cfg["training"]["seed"],6,cfg["training"].get("sample_limit"),exhaustive=True)
    loader=DataLoader(ds,batch_size=cfg["training"]["batch_size"],shuffle=False,num_workers=0)
    resnet=resnet18(weights=ResNet18_Weights.DEFAULT);resnet.fc=torch.nn.Identity();resnet.to(device).eval()
    stores={k:[] for k in ("full_model","dino_only","resnet18","handcrafted_structure")}
    model.eval()
    with torch.no_grad():
        for b in loader:
            x={k:b[k].to(device) for k in ("original_visual","candidate_visual","original_structure","candidate_structure","geometry_difference")}
            out=model(x);ro=resnet(x["original_visual"]);rh=resnet(x["candidate_visual"])
            dino=(F.cosine_similarity(out["original_embedding"],out["candidate_embedding"])+1)/2
            rn=(F.cosine_similarity(ro,rh)+1)/2;hand=torch.exp(-8*x["geometry_difference"].mean(1))
            for i in range(len(b["kind"])):
                stores["full_model"].append({"glyph_id":b["glyph_id"][i],"kind":b["kind"][i],"severity":float(b["severity"][i]),"scores":out["scores"][i].cpu().tolist(),"total":float(out["total"][i])})
                _record(stores,"dino_only",b,i,float(dino[i]));_record(stores,"resnet18",b,i,float(rn[i]));_record(stores,"handcrafted_structure",b,i,float(hand[i]))
    report={name:controlled_metrics(records) for name,records in stores.items()}
    report["note"]="ResNet18 and DINO-only are frozen pretrained retrieval baselines; full_model is the trained paired comparator."
    for spec in ablations:
        name,path=spec.split("=",1);amodel,a_ckpt,_=load_checkpoint(path,device);records=[]
        with torch.no_grad():
            for b in loader:
                x={k:b[k].to(device) for k in ("original_visual","candidate_visual","original_structure","candidate_structure","geometry_difference")};out=amodel(x)
                for i in range(len(b["kind"])): records.append({"glyph_id":b["glyph_id"][i],"kind":b["kind"][i],"severity":float(b["severity"][i]),"scores":out["scores"][i].cpu().tolist(),"total":float(out["total"][i])})
        report[f"ablation_{name}"]=controlled_metrics(records);report[f"ablation_{name}"]["checkpoint"]=str(Path(path).resolve())
    output=Path(checkpoint_path).with_name("baseline_benchmark.json");json_dump(report,output);return output


def main():
    p=argparse.ArgumentParser();p.add_argument("--checkpoint",required=True);p.add_argument("--ablation",action="append",default=[]);a=p.parse_args();print(run(a.checkpoint,a.ablation))
if __name__=="__main__":main()
