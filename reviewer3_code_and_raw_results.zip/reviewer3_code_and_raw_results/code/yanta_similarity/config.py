from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path

import numpy as np
import torch
import yaml


def load_config(path: str | Path) -> dict:
    path = Path(path).resolve()
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    config["_config_path"] = str(path)
    config["_config_dir"] = str(path.parent)
    return config


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_sha256(path: str | Path) -> str:

    path=Path(path)
    if path.is_file(): return sha256(path)
    digest=hashlib.sha256()
    for item in sorted(p for p in path.rglob("*") if p.is_file()):
        digest.update(item.relative_to(path).as_posix().encode("utf-8"));digest.update(bytes.fromhex(sha256(item)))
    return digest.hexdigest()


def json_dump(data: dict, path: str | Path) -> None:
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def refuse_forbidden_path(path: str | Path, config: dict) -> None:
    normalized = str(Path(path).resolve()).casefold()
    for token in config.get("data", {}).get("forbid_path_tokens", ["linben_cut_v2"]):
        if token.casefold() in normalized:
            raise ValueError(f"Refusing forbidden/unclean dataset path containing '{token}': {path}")
