from __future__ import annotations

import argparse, platform, time
from pathlib import Path
import pandas as pd
import torch
from torch.utils.data import DataLoader

from .config import load_config, seed_everything, refuse_forbidden_path, json_dump, sha256, tree_sha256
from .dataset import ControlledOriginalDataset
from .losses import objective_loss
from .model import YantaSimilarityNet


def _move(batch, device):
    keys = ("original_visual", "candidate_visual", "original_structure", "candidate_structure", "geometry_difference")
    return {k: batch[k].to(device, non_blocking=True) for k in keys}


def run(config_path: str):
    cfg = load_config(config_path); seed = int(cfg["training"]["seed"]); seed_everything(seed)
                                                         
    for key in ("original_metadata", "original_gray", "original_mask"):
        refuse_forbidden_path(cfg["data"][key], cfg)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data_hashes={k:tree_sha256(cfg["data"][k]) for k in ("original_metadata","original_gray","original_mask")}
    model = YantaSimilarityNet(cfg["backbone"], cfg.get("ablations")).to(device)
    resume=cfg["training"].get("resume_checkpoint")
    if resume:
        previous=torch.load(resume,map_location=device,weights_only=False)
        model.load_state_dict(previous["model_state"],strict=True)
    datasets = {s: ControlledOriginalDataset(cfg["data"]["original_metadata"], cfg["data"]["original_gray"],
                 cfg["data"]["original_mask"], s, seed, cfg["training"].get("samples_per_glyph", 2),
                 cfg["training"].get("sample_limit"),split_seed=cfg["training"].get("split_seed",seed)) for s in ("train", "val", "test")}
    loaders = {s: DataLoader(d, batch_size=cfg["training"]["batch_size"], shuffle=s=="train",
               num_workers=cfg["training"].get("workers", 0), pin_memory=device.type=="cuda") for s,d in datasets.items()}
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=float(cfg["training"]["lr"]), weight_decay=1e-4)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type=="cuda" and cfg["training"].get("amp", True))
    history=[]; best=float("inf"); started=time.time(); output=Path(cfg["output"]["training_dir"]); output.mkdir(parents=True, exist_ok=True)
    for epoch in range(int(cfg["training"]["epochs"])):
        datasets["train"].set_epoch(epoch)
        for phase in ("train", "val"):
            model.train(phase=="train"); total=0.; count=0
            for batch in loaders[phase]:
                x=_move(batch,device); target=batch["target"].float().to(device); severity=batch["severity"].float().to(device)
                with torch.amp.autocast("cuda", enabled=scaler.is_enabled()):
                    pred=model(x); loss,_=objective_loss(pred,target,severity)
                if phase=="train":
                    optimizer.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(optimizer); scaler.update()
                total += float(loss.detach())*target.shape[0]; count += target.shape[0]
            value=total/max(1,count); history.append({"epoch":epoch+1,"phase":phase,"loss":value})
            if phase=="val" and value<best:
                best=value
                payload={"model_state":model.state_dict(),"config":cfg,"backbone_name":model.backbone.name,
                         "backbone_weight_hash":model.backbone.weight_hash,"fusion_weights":model.fusion_weights.detach().cpu(),
                         "data_hashes":data_hashes,"epoch":epoch+1,"val_loss":best}
                torch.save(payload,output/"best.pt")
        print(f"epoch {epoch+1}: val={history[-1]['loss']:.5f}")
    pd.DataFrame(history).to_csv(output/"history.csv",index=False)
    checkpoint=output/"best.pt"
    report={"checkpoint":str(checkpoint.resolve()),"checkpoint_sha256":sha256(checkpoint),"device":str(device),
            "gpu":torch.cuda.get_device_name(0) if device.type=="cuda" else None,"python":platform.python_version(),
            "torch":torch.__version__,"elapsed_seconds":time.time()-started,"splits":{k:len(v) for k,v in datasets.items()},
            "data_hashes":data_hashes,"actual_backbone":model.backbone.name,"backbone_weight_hash":model.backbone.weight_hash,
            "fusion_weights":model.fusion_weights.detach().cpu().tolist(),"best_val_loss":best,
            "resume_checkpoint":resume,"formal_handwriting_used":False}
    json_dump(report, output/"training_report.json"); return report


def main():
    p=argparse.ArgumentParser(); p.add_argument("--config",required=True); args=p.parse_args(); print(run(args.config))
if __name__=="__main__": main()
