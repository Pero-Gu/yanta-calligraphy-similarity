from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn

from .config import sha256


class TinyPatchBackbone(nn.Module):

    def __init__(self, dim: int = 384):
        super().__init__()
        self.patch = nn.Conv2d(3, dim, 16, 16)
        self.embed_dim = dim

    def forward_features(self, image):
        tokens = self.patch(image).flatten(2).transpose(1, 2)
        return {"x_norm_patchtokens": tokens, "x_norm_clstoken": tokens.mean(1)}


class BackboneAdapter(nn.Module):
    def __init__(self, model: nn.Module, name: str, weight_hash: str | None, embed_dim: int = 384):
        super().__init__()
        self.model = model
        self.name = name
        self.weight_hash = weight_hash
        self.embed_dim = getattr(model, "embed_dim", embed_dim)
        for parameter in self.model.parameters():
            parameter.requires_grad = False
        self.model.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        self.model.eval()
        return self

    def forward(self, image):
        with torch.no_grad():
            output = self.model.forward_features(image)
        if isinstance(output, dict):
            tokens = output.get("x_norm_patchtokens")
            global_token = output.get("x_norm_clstoken")
        else:
            tokens = output[:, 1:]
            global_token = output[:, 0]
        if tokens is None:
            raise RuntimeError("Backbone did not return patch tokens")
        if global_token is None:
            global_token = tokens.mean(1)
        return tokens.float(), global_token.float()


def load_backbone(config: dict) -> BackboneAdapter:
    name = config.get("name", "dinov3_vits16")
    if name == "tiny_test":
        return BackboneAdapter(TinyPatchBackbone(), "tiny_test", None)
    repo = config.get("dinov3_repo")
    weights = config.get("dinov3_weights")
    if name.startswith("dinov3") and repo and weights and Path(repo).exists() and Path(weights).exists():
        model = torch.hub.load(repo, "dinov3_vits16", source="local", weights=str(Path(weights).resolve()))
        return BackboneAdapter(model, "dinov3_vits16", sha256(weights))
    if not config.get("allow_dinov2_fallback", True):
        raise RuntimeError("DINOv3 weights unavailable and DINOv2 fallback disabled")
    model = torch.hub.load("facebookresearch/dinov2", "dinov2_vits14",
                           trust_repo=True, skip_validation=True)
    cached = Path(torch.hub.get_dir()) / "checkpoints" / "dinov2_vits14_pretrain.pth"
    weight_hash = sha256(cached) if cached.exists() else "official_weight_not_located"
    return BackboneAdapter(model, "dinov2_vits14", weight_hash)
