from __future__ import annotations
import numpy as np


def _rank(a):
    a=np.asarray(a,float);order=np.argsort(a,kind="mergesort");ranks=np.empty(len(a),float);ranks[order]=np.arange(len(a),dtype=float)
    for value in np.unique(a):
        idx=np.where(a==value)[0];ranks[idx]=ranks[idx].mean()
    return ranks


def _spearman(a,b):
    ra,rb=_rank(a),_rank(b)
    if ra.std()==0 or rb.std()==0:return np.nan
    ra=ra-ra.mean();rb=rb-rb.mean()
    return float((ra*rb).sum()/np.sqrt((ra*ra).sum()*(rb*rb).sum()))


def _auc(labels, scores):
    positive=scores[labels==1];negative=scores[labels==0]
    if not len(positive) or not len(negative): return np.nan
    return float(((positive[:,None]>negative[None,:]).mean()+.5*(positive[:,None]==negative[None,:]).mean()))


def calibrated_ordinal_metrics(calibration_records, test_records):






    head={"layout":0,"stroke_geometry":1,"width_ink":2,"topology":3,"combined":4}

    def evidence(records):
        allowed={r["glyph_id"]:r for r in records if r["kind"]=="allowed"}
        rows=[]
        for r in records:
            kind=r["kind"]
            if kind in ("allowed","different"):
                continue
            baseline=allowed.get(r["glyph_id"])
            if baseline is None:
                continue
            index=head[kind]
            rows.append((kind,float(r["severity"]),float(baseline["scores"][index]-r["scores"][index])))
        return rows

    calibration=evidence(calibration_records)
    test=evidence(test_records)
    def fit_ordered_thresholds(rows):

        if not rows:
            return None
        values=np.asarray([r[2] for r in rows],float)
        labels=np.asarray([int(round(r[1]*4)) for r in rows],int)
        if len(np.unique(labels))<2:
            return None
        order=np.argsort(values,kind="mergesort")
        sv=values[order];sl=labels[order]
        n=len(sv);classes=(1,2,3,4)
        prefix=np.zeros((len(classes),n+1),int)
        for ci,klass in enumerate(classes):
            prefix[ci,1:]=np.cumsum(sl==klass)

        def correct(ci,start,end):
            return int(prefix[ci,end]-prefix[ci,start])

        dp=np.full((len(classes)+1,n+1),-10**9,int)
        back=np.zeros((len(classes)+1,n+1),int)
        dp[0,0]=0
        for ci in range(1,len(classes)+1):
            for end in range(0,n+1):
                best_score=-10**9;best_start=0
                for start in range(0,end+1):
                    score=dp[ci-1,start]+correct(ci-1,start,end)
                    if score>best_score:
                        best_score=score;best_start=start
                dp[ci,end]=best_score;back[ci,end]=best_start
        splits=[];end=n
        for ci in range(len(classes),0,-1):
            start=int(back[ci,end]);splits.append(start);end=start
        splits=list(reversed(splits))[1:]
        thresholds=[]
        margin=max(1e-6,float(np.std(sv))*1e-6)
        for split in splits:
            if split<=0:
                thresholds.append(float(sv[0]-margin))
            elif split>=n:
                thresholds.append(float(sv[-1]+margin))
            else:
                thresholds.append(float((sv[split-1]+sv[split])*.5))
        return tuple(thresholds)

    prototypes={}
    thresholds={}
    for kind in head:
        for severity in (.25,.5,.75,1.0):
            values=[value for k,s,value in calibration if k==kind and s==severity]
            if values:
                prototypes[(kind,severity)]=float(np.median(values))
        rows=[row for row in calibration if row[0]==kind]
        fitted=fit_ordered_thresholds(rows)
        if fitted is not None:
            thresholds[kind]=fitted
    true=[];pred=[]
                                                                         
    allowed_count=sum(r["kind"]=="allowed" for r in test_records)
    true.extend([0]*allowed_count);pred.extend([0]*allowed_count)
    levels=(.25,.5,.75,1.0)
    for kind,severity,value in test:
        available=[level for level in levels if (kind,level) in prototypes]
        if not available:
            continue
        prediction=min(available,key=lambda level:abs(value-prototypes[(kind,level)]))
        true.append(int(round(severity*4)));pred.append(int(round(prediction*4)))
    true=np.asarray(true);pred=np.asarray(pred)
    t_true=[];t_pred=[]
    t_true.extend([0]*allowed_count);t_pred.extend([0]*allowed_count)
    for kind,severity,value in test:
        if kind not in thresholds:
            continue
        t_true.append(int(round(severity*4)))
        t_pred.append(int(np.digitize(float(value),thresholds[kind],right=False)+1))
    t_true=np.asarray(t_true);t_pred=np.asarray(t_pred)
    return {
        "calibrated_ordinal_exact_accuracy":float(np.mean(true==pred)) if len(true) else None,
        "calibrated_ordinal_within_one_accuracy":float(np.mean(np.abs(true-pred)<=1)) if len(true) else None,
        "threshold_calibrated_ordinal_exact_accuracy":float(np.mean(t_true==t_pred)) if len(t_true) else None,
        "threshold_calibrated_ordinal_within_one_accuracy":float(np.mean(np.abs(t_true-t_pred)<=1)) if len(t_true) else None,
        "calibration_method":"validation_median_prototypes_with_per_glyph_allowed_baseline",
        "threshold_calibration_method":"validation_ordered_thresholds_with_per_glyph_allowed_baseline",
        "thresholds":{k:list(v) for k,v in thresholds.items()},
        "calibration_sample_count":len(calibration),
        "calibrated_test_sample_count":len(true),
    }


def controlled_metrics(records):

    result={}
    for index,name in enumerate(("layout","stroke_geometry","width_ink","topology","deep_visual")):
                                                                              
                                                                                
                                                           
        condition = "combined" if name == "deep_visual" else name
        subset=[r for r in records if r["kind"] == condition]
        if subset and "glyph_id" in subset[0]:
            values=[]
            for glyph in sorted({r["glyph_id"] for r in subset}):
                group=[r for r in subset if r["glyph_id"]==glyph];v=_spearman([r["severity"] for r in group],[r["scores"][index] for r in group])
                if not np.isnan(v): values.append(v)
            value=float(np.median(values)) if values else np.nan
        else:value=_spearman([r["severity"] for r in subset],[r["scores"][index] for r in subset]) if len(subset)>2 else np.nan
        result[f"{name}_severity_spearman"]=None if np.isnan(value) else float(value)
    combined=[r for r in records if r["kind"]=="combined"]
    combined_values=[]
    for glyph in sorted({r.get("glyph_id","") for r in combined}):
        group=[r for r in combined if r.get("glyph_id","")==glyph];v=_spearman([r["severity"] for r in group],[r["total"] for r in group])
        if not np.isnan(v):combined_values.append(v)
    result["combined_total_severity_spearman"]=float(np.median(combined_values)) if combined_values else None
    allowed=[r["total"] for r in records if r["kind"]=="allowed"]
    topology=[r["total"] for r in records if r["kind"]=="topology"]
    result["allowed_mean_drop_from_100"]=float(100*(1-np.mean(allowed))) if allowed else None
    result["topology_gap_from_allowed"]=float(100*(np.mean(allowed)-np.mean(topology))) if allowed and topology else None
    damage_records=[r for r in records if r["kind"]!="different"]
    labels=np.array([int(r["kind"]=="allowed") for r in damage_records]);values=np.array([r["total"] for r in damage_records])
    auc=_auc(labels,values);result["allowed_vs_damage_auc"]=None if np.isnan(auc) else auc
    head={"layout":0,"stroke_geometry":1,"width_ink":2,"topology":3}
    coefficient={"layout":.75,"stroke_geometry":.80,"width_ink":.85,"topology":.95}
    true_levels=[];pred_levels=[]
    levels=np.asarray([0,.25,.5,.75,1.])
    for r in records:
        if r["kind"]=="different": continue
        if r["kind"]=="allowed": estimate=0.
        elif r["kind"] in head:
            estimate=(1-float(r["scores"][head[r["kind"]]]))/coefficient[r["kind"]]
        else:
            coeff=np.asarray([.75,.80,.85,.95,.65]);estimate=float(np.mean((1-np.asarray(r["scores"]))/coeff))
        true_levels.append(int(np.argmin(np.abs(levels-float(r["severity"])))))
        pred_levels.append(int(np.argmin(np.abs(levels-np.clip(estimate,0,1)))))
    true_levels=np.asarray(true_levels);pred_levels=np.asarray(pred_levels)
    result["ordinal_exact_accuracy"]=float(np.mean(true_levels==pred_levels)) if len(true_levels) else None
    result["ordinal_within_one_accuracy"]=float(np.mean(np.abs(true_levels-pred_levels)<=1)) if len(true_levels) else None
    identity=[r for r in records if r["kind"] in ("allowed","different")]
    ilabels=np.asarray([int(r["kind"]=="allowed") for r in identity]);iscores=np.asarray([r["total"] for r in identity])
    iauc=_auc(ilabels,iscores);result["different_character_auc"]=None if np.isnan(iauc) else iauc
    return result
