from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .backbone import load_backbone


class ConvNeXtBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.depthwise = nn.Conv2d(channels, channels, 7, padding=3, groups=channels)
        self.norm = nn.GroupNorm(1, channels)
        self.pointwise = nn.Sequential(nn.Conv2d(channels, 4 * channels, 1), nn.GELU(),
                                       nn.Conv2d(4 * channels, channels, 1))

    def forward(self, x):
        return x + self.pointwise(self.norm(self.depthwise(x)))


class StructureEncoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv2d(5, 32, 4, 4), ConvNeXtBlock(32),
            nn.Conv2d(32, 64, 2, 2), ConvNeXtBlock(64),
            nn.Conv2d(64, 128, 2, 2), ConvNeXtBlock(128),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
        )

    def forward(self, image):
        return self.network(image)


class CrossCompareBlock(nn.Module):
    def __init__(self, dim: int = 256, heads: int = 4):
        super().__init__()
        self.o_to_h = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.h_to_o = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm_o = nn.LayerNorm(dim)
        self.norm_h = nn.LayerNorm(dim)

    def forward(self, original, candidate):
        cross_o, _ = self.o_to_h(original, candidate, candidate, need_weights=False)
        cross_h, _ = self.h_to_o(candidate, original, original, need_weights=False)
        return self.norm_o(original + cross_o), self.norm_h(candidate + cross_h)


class YantaSimilarityNet(nn.Module):
    score_names = ("layout", "stroke_geometry", "width_ink", "topology", "deep_visual")

    def __init__(self, backbone_config: dict, ablations: dict | None = None):
        super().__init__()
        self.ablations = ablations or {}
        self.backbone = load_backbone(backbone_config)
        dim = self.backbone.embed_dim
        self.adapter = nn.Sequential(nn.Linear(dim, 256), nn.GELU(), nn.LayerNorm(256))
        self.cross_blocks = nn.ModuleList([CrossCompareBlock(), CrossCompareBlock()])
        self.structure = StructureEncoder()
        self.geometry = nn.Sequential(nn.Linear(32, 128), nn.GELU(), nn.Linear(128, 128))
                                                                          
        fusion_dim = 5 * 256 + 2 * 128 + 128
        self.fusion = nn.Sequential(nn.Linear(fusion_dim, 512), nn.GELU(), nn.Dropout(.15),
                                    nn.Linear(512, 256), nn.GELU())
        self.heads = nn.ModuleDict({name: nn.Sequential(nn.Linear(256, 64), nn.GELU(),
                                                        nn.Linear(64, 1))
                                    for name in self.score_names})
        self.fusion_logits = nn.Parameter(torch.zeros(5))

    @property
    def fusion_weights(self):
        return torch.softmax(self.fusion_logits, dim=0)

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        original_tokens, original_global = self.backbone(batch["original_visual"])
        candidate_tokens, candidate_global = self.backbone(batch["candidate_visual"])
        original_tokens = self.adapter(original_tokens)
        candidate_tokens = self.adapter(candidate_tokens)
        original_global = self.adapter(original_global)
        candidate_global = self.adapter(candidate_global)
        initial_abs = torch.abs(original_tokens - candidate_tokens)
        initial_product = original_tokens * candidate_tokens
        token_cosine = F.cosine_similarity(original_tokens, candidate_tokens, dim=-1)
        if not self.ablations.get("remove_cross_attention", False):
            for block in self.cross_blocks:
                original_tokens, candidate_tokens = block(original_tokens, candidate_tokens)
        cross_abs = torch.abs(original_tokens - candidate_tokens)
        token_features = torch.cat([
            initial_abs.mean(1), initial_product.mean(1), cross_abs.mean(1),
            original_tokens.mean(1) - candidate_tokens.mean(1),
            torch.abs(original_global - candidate_global),
        ], dim=1)
        so = self.structure(batch["original_structure"])
        sh = self.structure(batch["candidate_structure"])
        structure_features = torch.cat([torch.abs(so - sh), so * sh], dim=1)
        geometry_features = self.geometry(batch["geometry_difference"])
        if self.ablations.get("remove_structure", False): structure_features = torch.zeros_like(structure_features)
        if self.ablations.get("remove_geometry", False): geometry_features = torch.zeros_like(geometry_features)
        representation = self.fusion(torch.cat([token_features, structure_features, geometry_features], dim=1))
        raw_scores = torch.cat([self.heads[name](representation) for name in self.score_names], dim=1)
        scores = torch.sigmoid(raw_scores)
        identical = ((batch["original_visual"]-batch["candidate_visual"]).abs().flatten(1).amax(1)<1e-7)
        identical &= (batch["geometry_difference"].abs().amax(1)<1e-7)
        scores = torch.where(identical[:,None], torch.ones_like(scores), scores)
        total = (scores * self.fusion_weights[None]).sum(1)
        branch_disagreement = scores.std(1, unbiased=False)
        side = int(round(token_cosine.shape[1] ** .5))
        token_difference = 1 - token_cosine
        if side * side == token_difference.shape[1]:
            token_difference = token_difference.reshape(-1, side, side)
        return {
            "scores": scores, "total": total, "representation": representation,
            "original_embedding": original_global, "candidate_embedding": candidate_global,
            "branch_disagreement": branch_disagreement, "token_difference": token_difference,
            "fusion_weights": self.fusion_weights,
        }
