from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import torch
from scipy import ndimage as ndi
from skimage.morphology import skeletonize


def read_gray(path: str | Path) -> np.ndarray:
    data = np.fromfile(str(path), np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(path)
    return image


def foreground_from_mask(image: np.ndarray) -> np.ndarray:
    return image < 128


def edge_map(mask: np.ndarray) -> np.ndarray:
    return mask ^ ndi.binary_erosion(mask)


def skeleton_map(mask: np.ndarray) -> np.ndarray:
    return skeletonize(mask)


def endpoint_junction_counts(skeleton: np.ndarray) -> tuple[int, int]:
    neighbours = ndi.convolve(skeleton.astype(np.uint8), np.ones((3, 3), np.uint8), mode="constant")
    neighbours = neighbours - skeleton.astype(np.uint8)
    endpoints = int(np.count_nonzero(skeleton & (neighbours == 1)))
    junctions = int(np.count_nonzero(skeleton & (neighbours >= 3)))
    return endpoints, junctions


def hole_count(mask: np.ndarray) -> int:
    filled = ndi.binary_fill_holes(mask)
    holes = filled & ~mask
    return max(0, ndi.label(holes)[1])


def structure_channels(gray: np.ndarray, mask: np.ndarray) -> np.ndarray:
    gray = cv2.resize(gray, (256, 256), interpolation=cv2.INTER_AREA)
    mask = cv2.resize(mask.astype(np.uint8), (256, 256), interpolation=cv2.INTER_NEAREST).astype(bool)
    edge = edge_map(mask)
    skeleton = skeleton_map(mask)
    distance = ndi.distance_transform_edt(mask)
    if distance.max() > 0:
        distance = distance / distance.max()
    ink = 1.0 - gray.astype(np.float32) / 255.0
    return np.stack([ink, mask, edge, distance, skeleton], axis=0).astype(np.float32)


def geometry_features(mask: np.ndarray) -> np.ndarray:
    mask = cv2.resize(mask.astype(np.uint8), (256, 256), interpolation=cv2.INTER_NEAREST).astype(bool)
    points = cv2.findNonZero(mask.astype(np.uint8))
    if points is None:
        return np.zeros(32, np.float32)
    x, y, w, h = cv2.boundingRect(points)
    ys, xs = np.where(mask)
    area = float(mask.mean())
    perimeter = float(np.count_nonzero(edge_map(mask))) / (2 * (256 + 256))
    labels = ndi.label(mask)[1]
    holes = hole_count(mask)
    skel = skeleton_map(mask)
    endpoints, junctions = endpoint_junction_counts(skel)
    widths = 2 * ndi.distance_transform_edt(mask)[skel]
    width_q = np.quantile(widths, [.25, .5, .75]) / 256 if widths.size else np.zeros(3)
    base = np.array([
        xs.mean() / 255, ys.mean() / 255, x / 255, y / 255, w / 256, h / 256,
        area, perimeter, w / max(1, h), min(labels, 20) / 20,
        min(holes, 10) / 10, min(endpoints, 40) / 40, min(junctions, 80) / 80,
        *width_q.tolist(),
    ], np.float32)
    occupancy = []
    for row in range(4):
        for col in range(4):
            tile = mask[row * 64:(row + 1) * 64, col * 64:(col + 1) * 64]
            occupancy.append(float(tile.mean()))
    return np.concatenate([base, np.asarray(occupancy, np.float32)])


def image_tensor(gray: np.ndarray, size: int = 224) -> torch.Tensor:
    resized = cv2.resize(gray, (size, size), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    tensor = torch.from_numpy(np.repeat(resized[None], 3, axis=0))
    mean = torch.tensor([.485, .456, .406])[:, None, None]
    std = torch.tensor([.229, .224, .225])[:, None, None]
    return (tensor - mean) / std


def pair_tensors(original_gray: np.ndarray, original_mask: np.ndarray,
                 candidate_gray: np.ndarray, candidate_mask: np.ndarray) -> dict[str, torch.Tensor]:
    go, gh = geometry_features(original_mask), geometry_features(candidate_mask)
    return {
        "original_visual": image_tensor(original_gray),
        "candidate_visual": image_tensor(candidate_gray),
        "original_structure": torch.from_numpy(structure_channels(original_gray, original_mask)),
        "candidate_structure": torch.from_numpy(structure_channels(candidate_gray, candidate_mask)),
        "geometry_difference": torch.from_numpy(np.abs(go - gh)),
    }
