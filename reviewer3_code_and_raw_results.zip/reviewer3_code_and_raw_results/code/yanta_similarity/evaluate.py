from __future__ import annotations
import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from .config import json_dump
from .dataset import ControlledOriginalDataset
from .metrics import controlled_metrics, calibrated_ordinal_metrics
from .runtime import load_checkpoint


def _records(model, device, cfg, split, seed):
    ds=ControlledOriginalDataset(cfg["data"]["original_metadata"],cfg["data"]["original_gray"],cfg["data"]["original_mask"],
        split,seed,max(6,cfg["training"].get("samples_per_glyph",2)),cfg["training"].get("sample_limit"),exhaustive=True,split_seed=cfg["training"].get("split_seed",seed))
    loader=DataLoader(ds,batch_size=cfg["training"]["batch_size"],shuffle=False,num_workers=0);records=[]
    with torch.no_grad():
        for b in loader:
            x={k:b[k].to(device) for k in ("original_visual","candidate_visual","original_structure","candidate_structure","geometry_difference")};out=model(x)
            for i in range(len(b["kind"])):records.append({"glyph_id":b["glyph_id"][i],"kind":b["kind"][i],"severity":float(b["severity"][i]),"scores":out["scores"][i].cpu().tolist(),"total":float(out["total"][i])})
    return records


def run(checkpoint_path):
    model,ckpt,device=load_checkpoint(checkpoint_path);cfg=ckpt["config"];seed=cfg["training"]["seed"]
    model.eval();calibration_records=_records(model,device,cfg,"val",seed);records=_records(model,device,cfg,"test",seed)
    report=controlled_metrics(records);report.update(calibrated_ordinal_metrics(calibration_records,records));names=("allowed","layout","stroke_geometry","width_ink","topology","combined")
    report["acceptance"]={"all_severity_abs_spearman_ge_0_90":all(abs(report.get(f"{n}_severity_spearman") or 0)>=.9 for n in names[1:5]),
        "allowed_drop_le_5":(report["allowed_mean_drop_from_100"] or 999)<=5,"topology_gap_ge_10":(report["topology_gap_from_allowed"] or -999)>=10,
        "auc_ge_0_95":(report["allowed_vs_damage_auc"] or 0)>=.95,
        "different_character_auc_ge_0_95":(report["different_character_auc"] or 0)>=.95,
        "ordinal_within_one_accuracy_ge_0_85":(report["ordinal_within_one_accuracy"] or 0)>=.85,
        "calibrated_ordinal_exact_accuracy_ge_0_85":(report["calibrated_ordinal_exact_accuracy"] or 0)>=.85}
    output=Path(checkpoint_path).with_name("controlled_test_report.json");json_dump(report,output);return output


def main():
    p=argparse.ArgumentParser();p.add_argument("--checkpoint",required=True);a=p.parse_args();print(run(a.checkpoint))
if __name__=="__main__":main()
