from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd

FIELDS=["layout_score","stroke_geometry_score","width_ink_score","topology_score","deep_visual_score","total_similarity","uncertainty"]
def ci(values,rng,n=5000):
    v=np.asarray(values,float);means=np.mean(rng.choice(v,(n,len(v)),replace=True),axis=1)
    return float(v.mean()),float(np.quantile(means,.025)),float(np.quantile(means,.975))
def main():
    p=argparse.ArgumentParser();p.add_argument("--scores",type=Path,required=True);p.add_argument("--model-report",type=Path,required=True);p.add_argument("--pair-audit",type=Path,required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    f=pd.read_csv(a.scores);f=f[f.quality_status=="accepted"];rng=np.random.default_rng(20260902);rows=[]
    for writer,g in list(f.groupby("writer"))+[("Overall",f)]:
        row={"writer":writer,"n":len(g)}
        for field in FIELDS:
            mean,lo,hi=ci(g[field],rng);row[field+"_mean"]=mean;row[field+"_ci95_low"]=lo;row[field+"_ci95_high"]=hi
        rows.append(row)
    pd.DataFrame(rows).to_csv(a.output/"table_handwriting_scores_bootstrap.csv",index=False,encoding="utf-8-sig")
    f.melt(
        id_vars=["pair_id","writer","original_id","handwritten_id","quality_status"],
        value_vars=FIELDS,
        var_name="metric",
        value_name="score",
    ).to_csv(a.output/"plot_handwriting_scores_long.csv",index=False,encoding="utf-8-sig")
    report=json.loads(a.model_report.read_text(encoding="utf-8"));audit=pd.read_csv(a.pair_audit).iloc[0].to_dict()
    model={
        "ordinal_within_one_accuracy":report["ordinal_within_one_accuracy"],
        "ordinal_exact_accuracy":report["ordinal_exact_accuracy"],
        "calibrated_ordinal_exact_accuracy":report.get("calibrated_ordinal_exact_accuracy"),
        "calibrated_ordinal_within_one_accuracy":report.get("calibrated_ordinal_within_one_accuracy"),
        "threshold_calibrated_ordinal_exact_accuracy":report.get("threshold_calibrated_ordinal_exact_accuracy"),
        "threshold_calibrated_ordinal_within_one_accuracy":report.get("threshold_calibrated_ordinal_within_one_accuracy"),
        "damage_auc":report["allowed_vs_damage_auc"],
        "different_character_auc":report["different_character_auc"],
        "topology_gap":report["topology_gap_from_allowed"],
        "pairing_preaudit_accuracy":audit["preaudit_identity_accuracy"],
        "formal_pairs":int(audit["formal_pairs"]),
    }
    pd.DataFrame([model]).to_csv(a.output/"table_model_performance.csv",index=False,encoding="utf-8-sig")
    print(pd.DataFrame(rows)[["writer","n","total_similarity_mean","total_similarity_ci95_low","total_similarity_ci95_high"]].to_string(index=False))
if __name__=="__main__":main()
