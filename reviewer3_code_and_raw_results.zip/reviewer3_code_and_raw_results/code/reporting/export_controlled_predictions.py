from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from yanta_similarity.evaluate import _records
from yanta_similarity.runtime import load_checkpoint


SCORE_NAMES = (
    "layout_score",
    "stroke_geometry_score",
    "width_ink_score",
    "topology_score",
    "deep_visual_score",
)


def export_split(model, device, cfg, split: str, seed: int, output: Path) -> int:
    rows = _records(model, device, cfg, split, seed)
    flattened = []
    for row in rows:
        record = {
            "split": split,
            "glyph_id": row["glyph_id"],
            "damage_family": row["kind"],
            "severity": row["severity"],
            "total_score": row["total"],
        }
        record.update(dict(zip(SCORE_NAMES, row["scores"])))
        flattened.append(record)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(flattened).to_csv(output, index=False)
    return len(flattened)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    model, checkpoint, device = load_checkpoint(args.checkpoint)
    cfg = checkpoint["config"]
    root = args.project_root.resolve()
    cfg["data"]["original_metadata"] = str(root / "yanta_enhanced_v2" / "metadata" / "glyphs.csv")
    cfg["data"]["original_gray"] = str(root / "yanta_enhanced_v2" / "enhanced_glyphs" / "gray_enhanced")
    cfg["data"]["original_mask"] = str(root / "yanta_enhanced_v2" / "enhanced_glyphs" / "mask")
    seed = int(cfg["training"]["seed"])

    counts = {}
    for split in ("val", "test"):
        path = args.output_dir / f"controlled_{split}_predictions.csv"
        counts[split] = export_split(model, device, cfg, split, seed, path)
    print(f"device={device}; validation_rows={counts['val']}; test_rows={counts['test']}")


if __name__ == "__main__":
    main()
